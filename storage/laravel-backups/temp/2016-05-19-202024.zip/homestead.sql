
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `adjudications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adjudications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_ruling` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `moderation_id` int(10) unsigned NOT NULL,
  `intolerance_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `adjudications_moderation_id_foreign` (`moderation_id`),
  KEY `adjudications_intolerance_id_foreign` (`intolerance_id`),
  KEY `adjudications_user_id_foreign` (`user_id`),
  CONSTRAINT `adjudications_intolerance_id_foreign` FOREIGN KEY (`intolerance_id`) REFERENCES `intolerances` (`id`),
  CONSTRAINT `adjudications_moderation_id_foreign` FOREIGN KEY (`moderation_id`) REFERENCES `moderations` (`id`),
  CONSTRAINT `adjudications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `adjudications` WRITE;
/*!40000 ALTER TABLE `adjudications` DISABLE KEYS */;
INSERT INTO `adjudications` VALUES (1,'tester',8,15,1,'2016-01-25 11:37:31','2016-01-25 11:37:31'),(2,'This is my admin current',8,15,1,'2016-01-25 11:43:09','2016-01-25 11:43:09'),(5,'This is done and locked',10,18,1,'2016-01-27 08:17:06','2016-01-27 08:17:06'),(6,'testers asd',10,18,1,'2016-01-27 08:18:28','2016-01-27 08:18:28'),(7,'Yes sorry this isi intolerance',11,19,1,'2016-01-27 08:36:24','2016-01-27 08:36:24'),(8,'This is labeled as intolernace',12,15,1,'2016-01-28 01:34:37','2016-01-28 01:34:37'),(11,'Swearing is not allowed.',16,21,1,'2016-04-02 22:46:31','2016-04-02 22:46:31'),(12,'This has been adjudicated',17,22,1,'2016-04-07 07:27:01','2016-04-07 07:27:01');
/*!40000 ALTER TABLE `adjudications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `elevation` int(10) unsigned NOT NULL,
  `extension` int(10) unsigned NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `artists` WRITE;
/*!40000 ALTER TABLE `artists` DISABLE KEYS */;
/*!40000 ALTER TABLE `artists` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `beacon_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beacon_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `belief` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `admin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zip` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `beacon_requests` WRITE;
/*!40000 ALTER TABLE `beacon_requests` DISABLE KEYS */;
INSERT INTO `beacon_requests` VALUES (3,'What about this','Atheism','Thsifsdfasdf','US','SW','https://google.com','234-234-23423',20,'2016-04-07 20:14:07','2016-04-07 21:38:04','Tre-Uniti','Requested','asdfasdf@c.com',NULL),(4,'My new beacon','Adaptia','Asdfasdfasdf','Ascension Island','asdfasdfasdf','asdfasdfasdf','asdfasdfasdf',1,'2016-04-19 06:38:54','2016-04-19 06:38:54','Tre-Uniti','Requested','asdfasdfasdf@g.com',NULL),(5,'Ingress','Atheism','234 @32 asdfasdf','DZ','Sedro Woolley','https://belle-idee.org','+1 (360) 333-8783',1,'2016-05-09 01:56:41','2016-05-09 01:56:41','Tre-Uniti','Requested','b@belle-idee.org',NULL),(6,'Deletions','Druze','23423423','DZ','asdfasdf','asdfasdfasdfasdf','23423423423',33,'2016-05-12 02:36:26','2016-05-12 02:36:26','Tre-Uniti','Requested','asd2fasdf@belle-idee.org','2342342');
/*!40000 ALTER TABLE `beacon_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `beacons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beacons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `beacon_tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `belief` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tag_usage` int(10) unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `manager` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stripe_active` tinyint(4) NOT NULL DEFAULT '0',
  `stripe_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stripe_subscription` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stripe_plan` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_four` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `subscription_ends_at` timestamp NULL DEFAULT NULL,
  `guide` int(10) unsigned DEFAULT NULL,
  `photo_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lat` double(10,6) DEFAULT NULL,
  `long` double(10,6) DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag_views` int(10) unsigned NOT NULL,
  `total_tag_usage` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `beacons_beacon_tag_unique` (`beacon_tag`),
  UNIQUE KEY `beacons_beacon_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `beacons` WRITE;
/*!40000 ALTER TABLE `beacons` DISABLE KEYS */;
INSERT INTO `beacons` VALUES (7,'Immacluate Heart of Mary','US-SW-IHOM','Christianity','http://www.svcc.us/ihm/index.html','3603338783','bmcgoffin13@gmail.com',0,'requested','US','Sedro-Woolley-SW',1,'2015-12-21 05:50:52','2016-05-12 21:42:19','268 Burrows Lane',1,'cus_7xryDR5uYa8dfr','sub_7xryHWxP6GmAyP','0',NULL,'2016-03-25 06:34:56',NULL,0,'/beacon_photos/7/Immacluate_Heart_of_Mary-May-02-2016.jpg',48.505077,-122.230191,NULL,0,0),(11,'Brendan McGoffin','us-us-sasdf','Adaptia','','3603338783','bmcgoffin144@gmail.com',0,'requested','','',1,'2015-12-21 06:25:52','2015-12-21 06:25:52','268 Burrows Lane',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0),(12,'Another','PHI-US-SDF','Christianity','asdfasdfasdf','0','bas@m.com',0,'requested','','',1,'2015-12-21 06:28:01','2016-05-08 23:30:01','asdfasdf',1,'cus_8PqalVg97MY2M4','sub_8PqaTEFLsIw8XB','3','0505','2016-06-07 23:00:52',NULL,2,'/beacon_photos/12/Another.jpg',NULL,NULL,NULL,0,0),(13,'Misdfs','US-SA-HASDF','Adaptia','asdfasdfasdf','0','asfsdf@mco.com',1,'requested','','',1,'2015-12-21 06:30:32','2016-05-13 18:08:06','asdfasdf',0,NULL,NULL,NULL,NULL,NULL,NULL,0,'/beacon_photos/13/Misdfs.jpg',NULL,NULL,NULL,0,0),(14,'5ths aSt  cmosdf ','US-SDF-SDFS','Ba Gua','asdfasdfasdf','0','239429C2@cm.com',0,'requested','','',1,'2015-12-21 06:31:13','2015-12-21 06:31:13','aw342fwef',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0),(15,'another beacon','us-as-sdf2','Christianity','asdfasdfas;lkj','0','bmcgoffin14@gamail.com',0,'requested','','',1,'2015-12-21 06:31:42','2015-12-21 06:31:42','268 Burrows Lane',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0),(16,'7th Advent','US-SW-7DA','Christianity','asdfa;slkj','3823423772','bas@cmil.com',0,'requested','','',1,'2015-12-21 06:33:34','2015-12-21 06:33:34','asf238fasdl;f',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0),(17,'2323f','PH-HID-D323','Adaptia','asdfj;lkj232','0','2bs@g.com',0,'requested','','',1,'2015-12-21 06:34:03','2015-12-21 06:34:03','a13rf',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0),(18,'9th Bible Gateway','Us-FD-FW','Buddhism','alkjf;laskdjf','0','asdfa@c.omc',0,'requested','','',1,'2015-12-21 06:34:49','2016-05-12 06:36:44','asdfasdf',1,'cus_8R1AH1gXVCpI7j','sub_8R1AgimdC9GRKy','3','9424','2016-06-11 02:01:01',NULL,1,'/beacon_photos/18/9th_Bible_Gateway.jpg',NULL,NULL,NULL,0,0),(19,'13th Beacon','CH-DI-DFWD','Adaptia','fasdfa;lkj23Fa','0','abmcls@cml.com',0,'deactivated','','',1,'2015-12-21 06:35:49','2016-05-18 23:36:52','asdfa;l2k3d',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0),(20,'11th ','MI-DI-32','Druze','f23fas23lkjfkj','4294967295','bmc@d.sco',0,'deactivated','AF','Sedro',1,'2015-12-21 06:36:27','2016-05-12 03:11:25','asf23flksjfk',0,'cus_8R1kk5HLFAwTBN','sub_8R1kl6oPwcxinB','2','9424','2016-06-11 02:36:53','2016-06-11 02:36:53',1,'',1234.000000,123.000000,'92342',0,0),(21,'12th Day','asdfh23f992','Urantia','aba;sldkf@vja;sldk','4294967295','bmc@cmo.org',0,'requested','','',1,'2015-12-21 06:37:03','2015-12-21 06:37:03','asdfl;2kfja;lskdjf',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,0,0),(22,'13th dab','US-f2@-@3','Adaptia','a;lsdkfjas;ldkfj','0','asb@cmo.com',0,'deactivated','','',1,'2015-12-21 06:37:21','2016-05-18 23:29:26','asdfsdfs',0,NULL,NULL,NULL,NULL,NULL,NULL,3,'/beacon_photos/22/13th_dab.jpg',NULL,NULL,NULL,0,0),(23,'Adaptia Center for Elevation','US-SW-ACE','Adaptia','https://tre-uniti.org','342','brendan.mcgoffin@tre-uniti.org',251,'requested','','',0,'2015-12-22 08:12:37','2016-05-16 20:10:10','268 Burrows Lane',1,'cus_8RTApRhI2FvW6w','sub_8RTAUJoRx3l3tG','3','4242','2016-06-12 06:56:31',NULL,0,'/beacon_photos/23/Adaptia_Center_for_Elevation.jpg',NULL,NULL,NULL,2500,22552),(24,'Look at this beacon','US-CS-SFR','Christianity','https://sdf.sdfcom','3603338783','2asdf@a.com',0,'requested','','',0,'2015-12-22 08:37:53','2016-05-12 21:42:19','asdfasdfs',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'/beacon_photos/24/Look_at_this_beacon.jpg',NULL,NULL,NULL,0,0),(25,'New Beacon24','US-SW-IHOM2','Druze','https://tre-uniti.org','4294967295','2342342@g.acom',0,'requested','US','Sedro Woolley-SW',0,'2016-01-14 01:58:27','2016-05-12 21:42:19','a23452sdfsdf',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'/beacon_photos/25/New_Beacon24.jpg',0.000000,0.000000,NULL,0,0),(26,'New Beacon 3','US-MA-BAAJ','Ba Gua','https://google.com','3220234234','basdf@g.asomc',0,'requested','','',1,'2016-02-24 03:56:31','2016-02-24 03:57:28','234 Biasdf ',0,NULL,NULL,NULL,NULL,NULL,NULL,3,'/beacon_photos/26/New_Beacon_3.jpg',NULL,NULL,NULL,0,0),(27,'Big Beacon','US-CS-SES3','Islam','http://yahoo.com','3232342234','bmcgoffin14@gmail.com2',0,'deactivated','','',1,'2016-02-24 03:58:11','2016-05-12 06:36:44','268 Burrows Lane',0,'cus_8R1G5MInnVVt4O','sub_8R1GabnNCHb9Zy','2','9424','2016-06-11 02:06:21','2016-06-11 02:06:21',0,'/beacon_photos/27/Big_Beacon.jpg',NULL,NULL,NULL,0,0),(28,'More Beacon','MS-SD-S3f','Buddhism','http://msn.com','2342923423','2342asC2@c.com',0,'deactivated','','',1,'2016-02-24 03:59:41','2016-05-18 23:28:57','234',0,NULL,NULL,NULL,NULL,NULL,NULL,7,'/beacon_photos/28/More_Beacon.jpg',NULL,NULL,NULL,0,0),(29,'Aspetta ','IT-FL-DUOMO','Christianity','http://gonzaga.edu','4294967295','afasdfasdf@caom.com',0,'requested','','',1,'2016-02-24 04:03:10','2016-02-24 04:03:10','sdf23232',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/beacon_photos//Aspetta_.jpg',NULL,NULL,NULL,0,0),(30,'Yippie','MA-JS-DFWD','Buddhism','http://microsoft.com','4294967295','avasdc@c.mom',0,'requested','AF','Sedro-Woolley-SW',1,'2016-02-24 04:08:35','2016-05-02 06:35:22','23423',0,NULL,NULL,NULL,NULL,NULL,NULL,2,'/beacon_photos/30/Yippie.jpg',0.000000,0.000000,NULL,0,0),(31,'Stripe','US-SF-Sdfw','Adaptia','https://stripe.com','4294967295','bmcgoffin@zagmail.gonzaga.edu',0,'requested','AF','Sedro-Woolley-SW',1,'2016-02-24 06:43:56','2016-05-12 06:36:44','PO Box 888',1,'cus_7xs8W3rpF1LyvI','sub_7xs8WLeLvuvJ7G','1',NULL,'2016-03-25 06:44:48',NULL,0,'/beacon_photos/31/Stripe.jpg',0.000000,0.000000,NULL,0,0),(32,'This is a new beacon','US-CS-S2','Buddhism','https://google.com','2342234234','bmcgoffin142@gmail.com',0,'requested','AF','Sedro-Woolley-SW',1,'2016-03-22 08:13:47','2016-05-02 06:35:44','asdfadsfasdf',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'/beacon_photos/32/This_is_a_new_beacon.jpg',0.000000,0.000000,NULL,0,0),(33,'My cool beacon','US-SW-MCB','Adaptia','http://microsoft.com','232','bmcgoffin1422@gmail.com',0,'active','AF','Sedro-Woolley-SW',1,'2016-03-23 02:40:56','2016-05-02 06:35:33','2342 Burows Lane',1,'cus_88IXGMG1H563W7','sub_88IXltMzsblHpm','2','1117','2016-04-22 02:42:00',NULL,1,'/beacon_photos/33/My_cool_beacon.jpg',0.000000,0.000000,NULL,0,0),(36,'This is my test Beacon','US-AR-023','Christianity','https://google.com','342-232-3423','bmcgoffin17@gmail.com',0,'active','AF','Sedro-Woolley-SW',4,'2016-03-23 04:17:59','2016-05-02 06:35:12','This is great!',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'/beacon_photos/36/This_is_my_test_Beacon.jpg',0.000000,0.000000,NULL,0,0),(37,'another test','US-MS-HSD','Buddhism','http://yahoo.com','342-2342-2323','brendan.mcgoffin2@tre-uniti.org',0,'active','AF','Sedro-Woolley-SW',1,'2016-03-23 04:21:48','2016-05-02 06:34:56','2342 Bsu2',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'/beacon_photos/37/another_test.jpg',0.000000,0.000000,NULL,0,0),(38,'final test','PI-CB-023','Judaism','https://facebook.com','342-234-2342','viviantan_01@yahoo.com',0,'active','AF','Sedro-Woolley-SW',1,'2016-03-23 04:26:14','2016-05-02 06:34:47','2234 Mewss',1,'cus_88KDKQwGdCs86i','sub_88KDkl2j8pbzLK','3','0000','2016-04-22 04:26:15',NULL,1,'/beacon_photos/38/final_test.jpg',0.000000,0.000000,NULL,0,0),(39,'My first new beacon','US-SW-SF','Atheism','http://gonzaga.edu','234-234-2342','bmcasd@c.com',0,'active','AS','Sedro-Woolley-SW',1,'2016-03-23 04:31:07','2016-05-02 06:32:19','2342 Burows Lane 2',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'/beacon_photos/39/My_first_new_beacon.jpg',0.000000,0.000000,NULL,0,0),(40,'Email tester too','US-OS-US','Hinduism','http://gonzaga.edu','342-234-2342','b2mcgoffin14@gmail.com',0,'active','AF','Sedro-Woolley-SW',1,'2016-03-23 04:33:41','2016-05-02 06:34:21','234 Mse ',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'/beacon_photos/40/Email_tester_too.jpg',0.000000,0.000000,NULL,0,0),(41,'Wish this would','US-OS-01','Adaptia','https://google.com','234-23402342','asdf@ac.om',0,'active','AF','Sedro-Woolley-SW',1,'2016-03-23 04:36:25','2016-05-03 18:34:31','2342 Burows Lane',1,'cus_8NuADCQOtBubGf','sub_8NuArnkSFQ4hKa','3','4242','2016-06-02 18:34:30',NULL,0,'/beacon_photos/41/Wish_this_would.jpg',0.000000,0.000000,NULL,0,0),(43,'tester22','US-IS-02','Judaism','http://msn.com','322-342-2342','b2@gmail.com',0,'active','','',1,'2016-03-23 04:39:28','2016-03-23 04:39:29','234 Biasdf ',0,NULL,NULL,NULL,NULL,NULL,NULL,1,'/beacon_photos/43/tester22.jpg',NULL,NULL,NULL,0,0),(44,'Final Test of Beacon','MS-US-02','Taoism','https://google.com','+3 (323)-234-2323','b22@gmail.com',0,'active','AL','Sedro-Woolley-SW',1,'2016-03-23 04:42:48','2016-05-02 06:30:43','232 Mose',0,NULL,NULL,NULL,NULL,NULL,NULL,2,'/beacon_photos/44/Final_Test_of_Beacon.jpg',0.000000,0.000000,NULL,0,0),(45,'Christ the King','US-BHD-CTK','Christianity','https://google.com','323-234-2342','b2@gmac3.com',0,'active','AR','Sedro-Woolley-SW',1,'2016-03-23 04:44:33','2016-05-02 06:31:37','123 Bsurs Lane',1,'cus_88KWUt8TIMQ9dD','sub_88KWpAz3QP9ibj','0','0505','2016-04-22 04:44:27',NULL,2,'/beacon_photos/45/Christ_the_King.jpg',0.000000,0.000000,NULL,0,0),(46,'Last Shot','US-IS-LS','Adaptia','https://google.com','2323-23422-32','bs2D@g.com',0,'deactivated','BD','Sedro-Woolley-SW',1,'2016-03-23 04:47:22','2016-05-12 21:42:19','Sdfww32',0,'cus_8Qze8UKSpNaqmT','sub_8QzeAcSgEjQsKC','0','8431','2016-06-11 00:26:29','2016-06-11 00:26:29',1,'/beacon_photos/46/Last_Shot-Apr-11-2016.jpg',0.000000,0.000000,NULL,0,0),(47,'This is my test Beacon2','US-AR-@#@','Adaptia','https://google.com','342-232-3423','bmcgoffin170@gmail.com',0,'active','AF','Sedro-Woolley-SW',1,'2016-03-23 04:53:33','2016-05-02 06:31:15','This is great!',0,NULL,NULL,NULL,NULL,NULL,NULL,0,'/beacon_photos/47/This_is_my_test_Beacon2.jpg',0.000000,0.000000,NULL,0,0),(49,'His Place','US-BLR-HPCC','Christianity','https://google.com','324-234-2342','sdf@g.acom',0,'deactivated','US','Burlington-BLR',20,'2016-03-23 05:01:37','2016-05-12 21:42:19','234 Burs',0,'cus_8QxxDPZ6kD1ysm','sub_8QxxQTT0gfVgW0','0','8431','2016-06-10 22:42:06','2016-06-10 22:42:06',20,'/beacon_photos/49/His_Place.jpg',48.457810,-122.335173,NULL,0,0),(50,'tester2','US-SW-SUS','Adaptia','https://google.com','324-234-2342','bmcgoffin14@gmail.com',0,'active','AF','Sedro',1,'2016-03-25 21:41:21','2016-05-12 06:36:44','3242 Asdf ',1,'cus_8Qt9Q27jBuCW4j','sub_8Qt9OHQcXHUsWw','3','9424','2016-06-10 17:43:20',NULL,1,'/beacon_photos/50/tester2.jpg',48.464989,-122.322532,'34534',0,0),(51,'My new beacon request','USdf -asdf','Atheism','asadfasdfaf','2342342342','asdfa@c.com',0,'active','AF','asdf',20,'2016-03-31 18:19:40','2016-05-12 06:36:44','This is great!',1,'cus_8BXTJMskmYz7YS','sub_8BXTQFYjjCX3VX','2','4242','2016-04-30 18:20:08',NULL,20,'/beacon_photos/51/My_new_beacon_request.jpg',0.000000,0.000000,NULL,0,0),(52,'My transferred beacon','US-SW-23','Atheism','http://www.svcc.us/ihm/','2323234234','b@g.com',0,'active','AF','Sedro-Woolley-SW',20,'2016-04-15 06:07:02','2016-05-12 06:36:44','goodness!',1,'cus_8Gy2pgMPtTOEra','sub_8Gy2d2xusRiCkU','3','4242','2016-05-15 06:07:18',NULL,1,'/beacon_photos/52/My_transferred_beacon-Apr-27-2016.jpg',48.505077,-122.230191,NULL,0,0),(53,'Cathedral of Santa Maria del Fiore','IT-FLR-Duomo','Christianity','asdfasdfasdf','+1 (360) 333-8798','bmcgoffin14@gmail.comf',0,'active','IT','Firenze-FLR',33,'2016-04-26 06:45:24','2016-05-12 06:36:44','2342 Bsdfs osl',1,'cus_8L6KTnMabBvGKf','sub_8L6KKQ15PkyL25','2','1117','2016-05-26 06:56:55',NULL,1,'/beacon_photos/53/Duomo.jpg',43.773175,11.255949,NULL,0,0),(54,'Basilica of Santa Croce','IT-FLR-BOSC','Christianity','santacroceopera.it','+1 (324) 234-23423','whois@belle-idee.org',0,'active','IT','Firenze-FLR',1,'2016-04-29 20:20:57','2016-05-12 06:36:44','Piazza di Santa Croce, 16, 50122',1,'cus_8MQyhngGSigElN','sub_8MQy6MLwKrmseY','2','8210','2016-05-29 20:20:59',NULL,1,'/beacon_photos/54/Basilica_of_Santa_Croce.jpg',43.768576,11.262335,NULL,0,0),(55,'My test beacon','TT-BT-MTB','Druze','oasdfasdfasdf','2324-234232342','basd@c.a',0,'active','TT','BigTouf',1,'2016-05-09 05:36:34','2016-05-09 06:07:28','Tsasdfasd',1,'cus_8PxSa5BNTBVwXD','sub_8PxSHh6Nmqrcfj','3','4444','2016-06-08 06:06:45',NULL,2,'/beacon_photos/55/My_test_beacon.jpg',10.651941,-61.510985,NULL,0,0),(56,'Stripes','US-SW-STRIP','Christianity','https://belle-idee.org','+1 (360) 333-8232','bas@tre-uniti.org',0,'active','US','Sedro-Woolley',1,'2016-05-09 06:09:47','2016-05-09 06:10:33','268 Burrows Lane',1,'cus_8PxWeYJYj6jKkY','sub_8PxWitKvHEu0Wo','2','5100','2016-06-08 06:10:26',NULL,1,'/beacon_photos/56/Stripes-May-09-2016.jpg',48.507481,-122.249503,'98284',0,0),(57,'Ideas','US-SW-Idea','Christianity','http://msn.com','+1 234 234-2342','b@belle-idee.org',251,'active','US','Sedro Woolley',1,'2016-05-09 06:12:42','2016-05-13 18:38:28','223 ASDf',1,'cus_8Py0UDqtIh6WLk','sub_8Py0fRnNZgGAPR','3','5100','2016-06-08 06:41:04',NULL,1,'/beacon_photos/57/Ideas-May-09-2016.jpg',48.507481,-122.249503,'98284',2500,750),(58,'this delete','US-SW-HOSF','Hinduism','asdfasdfasdf','2234234234','basdf@c.om',0,'deactivated','AF','Sedro woo',1,'2016-05-11 21:29:30','2016-05-12 06:36:44','Asdfasdf',0,'cus_8QwnaCYBeNcYJj','sub_8QwnzcoVukVaQS','2','8210','2016-06-10 21:29:58','2016-06-10 21:29:58',1,'/beacon_photos/58/this_delete-May-11-2016.png',2342.000000,2342.000000,'92342',0,0),(59,'deletion','US-SW-SFS','Atheism','sasdf@asdf.com','12342342342','bm@tre-uniti.org',0,'deactivated','AL','US',1,'2016-05-11 22:19:25','2016-05-12 06:36:44','2342 Bsdf',0,'cus_8Qxb3KJMgZJgiV','sub_8QxbuxpDPJ6iNy','3','8431','2016-06-10 22:19:39','2016-06-10 22:19:39',11,'/beacon_photos/59/deletion-May-11-2016.png',9999.999999,9999.999999,'234234',0,0),(60,'asdfasdf','US-SW-3423','Buddhism','asdfasdfasdf','131232134234','asdfasdf@belle-idee.org2',0,'deactivated','AT','asdfasdf',1,'2016-05-11 22:29:08','2016-05-13 06:45:20','asdfasdfs',0,'cus_8Qxk44PZxwUYc4','sub_8QxkwVS8czvpM7','3','8431','2016-06-10 22:29:12','2016-06-10 22:29:12',1,'',9999.999999,9999.999999,'2342342',0,0);
/*!40000 ALTER TABLE `beacons` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bookmark_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookmark_user` (
  `bookmark_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `bookmark_user_bookmark_id_index` (`bookmark_id`),
  KEY `bookmark_user_user_id_index` (`user_id`),
  CONSTRAINT `bookmark_user_bookmark_id_foreign` FOREIGN KEY (`bookmark_id`) REFERENCES `bookmarks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookmark_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bookmark_user` WRITE;
/*!40000 ALTER TABLE `bookmark_user` DISABLE KEYS */;
INSERT INTO `bookmark_user` VALUES (10,6,'2016-02-16 00:26:27','2016-02-16 00:26:27'),(11,6,'2016-02-16 01:13:43','2016-02-16 01:13:43'),(12,6,'2016-02-16 01:17:07','2016-02-16 01:17:07'),(13,1,'2016-02-16 05:07:53','2016-02-16 05:07:53'),(14,1,'2016-02-16 05:21:50','2016-02-16 05:21:50'),(15,1,'2016-02-16 05:28:19','2016-02-16 05:28:19'),(16,1,'2016-02-16 06:32:51','2016-02-16 06:32:51'),(23,2,'2016-02-16 07:39:52','2016-02-16 07:39:52'),(24,2,'2016-02-16 07:39:57','2016-02-16 07:39:57'),(26,2,'2016-02-16 07:40:18','2016-02-16 07:40:18'),(27,2,'2016-02-16 07:47:35','2016-02-16 07:47:35'),(29,2,'2016-02-19 09:31:32','2016-02-19 09:31:32'),(30,1,'2016-02-22 23:59:16','2016-02-22 23:59:16'),(13,8,'2016-02-23 06:22:32','2016-02-23 06:22:32'),(11,1,'2016-02-23 06:24:45','2016-02-23 06:24:45'),(31,8,'2016-02-24 03:34:17','2016-02-24 03:34:17'),(32,1,'2016-02-24 06:50:01','2016-02-24 06:50:01'),(23,1,'2016-03-22 08:07:44','2016-03-22 08:07:44'),(33,1,'2016-03-23 05:28:54','2016-03-23 05:28:54'),(35,2,'2016-03-25 05:30:11','2016-03-25 05:30:11'),(34,13,'2016-03-25 06:17:28','2016-03-25 06:17:28'),(36,1,'2016-03-28 23:40:45','2016-03-28 23:40:45'),(39,1,'2016-04-11 07:58:20','2016-04-11 07:58:20'),(43,31,'2016-04-12 06:59:51','2016-04-12 06:59:51'),(38,31,'2016-04-12 07:00:13','2016-04-12 07:00:13'),(44,1,'2016-04-15 04:47:28','2016-04-15 04:47:28'),(38,1,'2016-04-15 04:52:38','2016-04-15 04:52:38'),(45,1,'2016-04-15 04:54:37','2016-04-15 04:54:37'),(46,1,'2016-04-15 04:57:03','2016-04-15 04:57:03'),(47,1,'2016-04-15 04:57:51','2016-04-15 04:57:51'),(48,1,'2016-04-15 06:07:58','2016-04-15 06:07:58'),(49,33,'2016-04-18 07:30:01','2016-04-18 07:30:01'),(48,8,'2016-04-21 22:04:35','2016-04-21 22:04:35'),(50,1,'2016-04-26 19:38:39','2016-04-26 19:38:39'),(48,29,'2016-04-27 01:59:05','2016-04-27 01:59:05'),(50,29,'2016-04-27 02:01:13','2016-04-27 02:01:13'),(50,33,'2016-04-28 07:19:43','2016-04-28 07:19:43'),(51,33,'2016-04-28 07:24:14','2016-04-28 07:24:14'),(52,1,'2016-04-29 19:41:02','2016-04-29 19:41:02'),(53,1,'2016-04-29 20:21:44','2016-04-29 20:21:44'),(53,33,'2016-04-29 20:30:13','2016-04-29 20:30:13'),(52,33,'2016-04-29 20:30:19','2016-04-29 20:30:19'),(53,15,'2016-05-01 03:28:45','2016-05-01 03:28:45'),(52,2,'2016-05-03 05:50:43','2016-05-03 05:50:43'),(55,1,'2016-05-09 06:45:13','2016-05-09 06:45:13'),(57,33,'2016-05-11 21:38:25','2016-05-11 21:38:25'),(24,1,'2016-05-12 02:01:44','2016-05-12 02:01:44'),(13,33,'2016-05-12 02:03:19','2016-05-12 02:03:19'),(63,35,'2016-05-13 18:37:56','2016-05-13 18:37:56'),(64,1,'2016-05-15 21:46:58','2016-05-15 21:46:58');
/*!40000 ALTER TABLE `bookmark_user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookmarks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pointer` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bookmarks` WRITE;
/*!40000 ALTER TABLE `bookmarks` DISABLE KEYS */;
INSERT INTO `bookmarks` VALUES (10,'US-SW-7DA','Beacon','2016-02-16 00:26:27','2016-02-16 00:26:27','7th Day'),(11,'US-SW-IHOM2','Beacon','2016-02-16 01:13:43','2016-02-16 01:13:43','New Beacon24'),(12,'39','Post','2016-02-16 01:17:07','2016-02-16 01:17:07','asdfasdfasdf'),(13,'US-CS-SFR','Beacon','2016-02-16 05:07:53','2016-02-16 05:07:53','Look at this beacon'),(14,'83','Extension','2016-02-16 05:21:50','2016-02-16 05:21:50','test of noti'),(15,'35','Post','2016-02-16 05:28:19','2016-02-16 05:28:19','tester roo'),(16,'7','Post','2016-02-16 06:32:50','2016-02-16 06:32:50','tester'),(17,'1','User','2016-02-16 06:46:19','2016-02-16 06:46:19','Tre-Uniti'),(18,'40','Post','2016-02-16 07:27:33','2016-02-16 07:27:33','This is also my question extension270'),(19,'38','Post','2016-02-16 07:28:19','2016-02-16 07:28:19','asdfasdf'),(20,'2','User','2016-02-16 07:32:39','2016-02-16 07:32:39','Amaricus'),(21,'86','Extension','2016-02-16 07:39:31','2016-02-16 07:39:31','another big one alith asooo long whatch '),(22,'82','Extension','2016-02-16 07:39:48','2016-02-16 07:39:48','asdfasdf2'),(23,'US-SW-ACE','Beacon','2016-02-16 07:39:52','2016-02-16 07:39:52','Adaptia Center for Elevation'),(24,'Us-FD-FW','Beacon','2016-02-16 07:39:57','2016-02-16 07:39:57','9th Bible Gateway'),(25,'2','User','2016-02-16 07:40:01','2016-02-16 07:40:01','Amaricus'),(26,'2','User','2016-02-16 07:40:18','2016-02-16 07:40:18','Amaricus'),(27,'5','User','2016-02-16 07:47:35','2016-02-16 07:47:35','zagmail'),(28,'6','User','2016-02-19 08:10:14','2016-02-19 08:10:14','BigBoyz'),(29,'43','Post','2016-02-19 09:31:32','2016-02-19 09:31:32','tester323'),(30,'US-SA-HASDF','Beacon','2016-02-22 23:59:16','2016-02-22 23:59:16','Misdfs'),(31,'45','Post','2016-02-24 03:34:17','2016-02-24 03:34:17','testas'),(32,'US-SF-Sdfw','Beacon','2016-02-24 06:50:01','2016-02-24 06:50:01','Stripe'),(33,'51','Post','2016-03-23 05:28:54','2016-03-23 05:28:54','My test drip post'),(34,'US-IS-022','Beacon','2016-03-23 05:29:08','2016-03-23 05:29:08','His Place'),(35,'53','Post','2016-03-25 05:30:11','2016-03-25 05:30:11','Thisis my tester'),(36,'54','Post','2016-03-28 23:40:45','2016-03-28 23:40:45','New poster'),(37,'55','Post','2016-04-07 06:58:46','2016-04-07 06:58:46','My new draft'),(38,'USdf -asdf','Beacon','2016-04-07 06:58:53','2016-04-07 06:58:53','My new beacon request'),(39,'144','Extension','2016-04-07 06:59:04','2016-04-07 06:59:04','My extension of this post'),(40,'9','User','2016-04-07 20:15:44','2016-04-07 20:15:44','noBeta'),(41,'57','Post','2016-04-07 20:15:52','2016-04-07 20:15:52','Hi this is my first post'),(42,'147','Extension','2016-04-07 22:23:27','2016-04-07 22:23:27','New extension'),(43,'68','Post','2016-04-12 06:59:51','2016-04-12 06:59:51','This is my longer posthis '),(44,'70','Post','2016-04-15 04:47:28','2016-04-15 04:47:28','My first post yupppie!'),(45,'MS-US-02','Beacon','2016-04-15 04:54:37','2016-04-15 04:54:37','Final Test of Beacon'),(46,'150','Extension','2016-04-15 04:57:03','2016-04-15 04:57:03','my new extension'),(47,'29','User','2016-04-15 04:57:51','2016-04-15 04:57:51','anothertest'),(48,'US-SW-23','Beacon','2016-04-15 06:07:58','2016-04-15 06:07:58','My transferred beacon'),(49,'71','Post','2016-04-18 07:30:01','2016-04-18 07:30:01','test post2342'),(50,'TK-Sesdr','Beacon','2016-04-26 19:38:39','2016-04-26 19:38:39','Duomo'),(51,'82','Post','2016-04-28 07:24:14','2016-04-28 07:24:14','This is my first post'),(52,'IT-FLR-Duomo','Beacon','2016-04-29 19:41:02','2016-04-29 19:41:02','Duomo'),(53,'IT-FLR-BOSC','Beacon','2016-04-29 20:21:44','2016-04-29 20:21:44','Basilica of Santa Croce'),(54,'US-BLR-HPCC','Beacon','2016-04-29 20:27:38','2016-04-29 20:27:38','His Place'),(55,'90','Post','2016-05-09 06:45:13','2016-05-09 06:45:13','My new post'),(56,'US-SW-HOSF','Beacon','2016-05-11 21:36:14','2016-05-11 21:36:14','this delete'),(57,'92','Post','2016-05-11 21:38:25','2016-05-11 21:38:25','My first post'),(58,'US-SW-SFS','Beacon','2016-05-11 22:20:24','2016-05-11 22:20:24','deletion'),(59,'US-SW-3423','Beacon','2016-05-11 22:29:27','2016-05-11 22:29:27','asdfasdf'),(60,'US-IS-LS','Beacon','2016-05-11 22:51:06','2016-05-11 22:51:06','Last Shot'),(61,'US-CS-SES3','Beacon','2016-05-12 02:04:09','2016-05-12 02:04:09','Big Beacon'),(62,'MI-DI-32','Beacon','2016-05-12 02:21:03','2016-05-12 02:21:03','11th '),(63,'US-SW-Idea','Beacon','2016-05-13 18:37:56','2016-05-13 18:37:56','Ideas'),(64,'95','Post','2016-05-15 21:46:58','2016-05-15 21:46:58','Hey my first post here!'),(65,'CH-DI-DFWD','Beacon','2016-05-18 23:30:35','2016-05-18 23:30:35','13th Beacon');
/*!40000 ALTER TABLE `bookmarks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `belief` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `beacon_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nymified` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `draft_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `drafts_user_id_foreign` (`user_id`),
  CONSTRAINT `drafts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES (2,'l',NULL,'US-SW-IHOM2',NULL,NULL,'/drafts/2/l.txt','2016-01-20 00:38:17','2016-01-20 00:38:17',2),(3,'Asdfasdf',NULL,'US-CS-SFW',NULL,NULL,'/drafts/2/Asdfasdf.txt','2016-01-20 02:47:04','2016-01-20 02:47:04',2),(4,'ltasdf',NULL,'US-CS-SFW',NULL,NULL,'/drafts/2/ltasdf.txt','2016-01-20 02:56:51','2016-01-20 02:56:51',2),(5,'tester',NULL,'US-CS-SFW',NULL,NULL,'/drafts/2/tester.txt','2016-01-20 03:02:58','2016-01-20 03:02:58',2),(6,'testsa','Ba Gua','US-CS-SFW','Opinion',NULL,'/drafts/2/testsa.txt','2016-01-20 03:05:34','2016-01-20 04:26:17',2),(7,'mytest','Atheism','US-SW-IHOM2','Opinion',NULL,'/drafts/2/mytest.txt','2016-01-20 03:10:25','2016-01-20 03:10:25',2),(8,'asdfasdfasdf','Ba Gua','No-Beacon','Scholar',NULL,'/drafts/6/asdfasdfasdf.txt','2016-01-27 07:49:43','2016-01-27 07:49:43',6),(9,'test draft','Atheism','No-Beacon','Story',NULL,'/drafts/6/test draft.txt','2016-01-27 23:15:25','2016-01-27 23:17:02',6),(10,'asdfasdfasdf2','Christianity','US-f2@-@3','Prayer',NULL,'/drafts/1/asdfasdfasdf2.txt','2016-01-29 01:18:44','2016-01-29 01:18:44',1),(11,'asdfasdfasd','Hinduism','US-SW-ACE','Prayer',NULL,'/drafts/1/asdfasdfasd.txt','2016-02-13 09:13:40','2016-02-13 09:13:49',1),(12,'my draft','Atheism','US-SW-ACE','Writings',NULL,'/drafts/2/my draft.txt','2016-02-17 06:59:48','2016-02-17 07:00:10',2),(13,'New drafter','Hinduism','No-Beacon','Reflection',NULL,'/drafts/1/New drafter.txt','2016-03-25 05:11:12','2016-03-25 05:12:04',1),(14,'Another drafter','Adaptia','US-SA-HASDF','Reflection',NULL,'/drafts/1/Another drafter.txt','2016-03-25 05:11:44','2016-03-25 05:11:44',1),(18,'New drafter23','Adaptia','US-SA-HASDF','Reflection',NULL,'/drafts/1/New drafter23.txt','2016-04-11 07:58:52','2016-04-11 07:58:52',1),(19,'Tjis is my test draft','Adaptia','US-SA-HASDF','Reflection',NULL,'/drafts/1/Tjis is my test draft.txt','2016-04-15 06:56:11','2016-04-15 06:56:11',1),(20,'My next draft','Ba Gua','US-CS-SFR','Reflection',NULL,'/drafts/1/My next draft.txt','2016-04-18 07:26:02','2016-04-18 07:26:02',1),(21,'My first draft','Christianity','US-BLR-HPCC','Reflection',NULL,'/drafts/1/My first draft.txt','2016-04-30 05:13:31','2016-04-30 05:13:31',1),(22,'This is a title of my new psot asdfasdf','Hinduism','US-SW-ACE','Nature',NULL,'/drafts/1/This is a title of my new psot asdfasdf.txt','2016-05-04 04:49:16','2016-05-04 04:49:42',1),(23,'this is a test','Adaptia','US-SA-HASDF','Discussion',NULL,'/drafts/1/this is a test.txt','2016-05-10 23:34:17','2016-05-10 23:34:17',1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `elevations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elevations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned DEFAULT NULL,
  `extension_id` int(10) unsigned DEFAULT NULL,
  `question_id` int(10) unsigned DEFAULT NULL,
  `legacy_post_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `source_user` int(10) unsigned NOT NULL,
  `beacon_tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `elevation_user_id_foreign` (`user_id`),
  CONSTRAINT `elevation_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `elevations` WRITE;
/*!40000 ALTER TABLE `elevations` DISABLE KEYS */;
INSERT INTO `elevations` VALUES (1,1,NULL,NULL,NULL,1,'2015-12-20 08:20:04','2016-04-29 21:46:48',2,'No Beacon'),(2,NULL,1,NULL,NULL,2,'2015-12-20 08:21:02','2016-04-29 21:46:48',1,'No Beacon'),(3,NULL,2,NULL,NULL,1,'2015-12-21 02:10:03','2016-04-29 21:51:24',2,'PH-CEB-CMC'),(4,3,NULL,NULL,NULL,2,'2015-12-21 02:17:34','2016-04-29 21:46:48',1,'No Beacon'),(5,4,NULL,NULL,NULL,1,'2015-12-21 07:21:02','2016-04-29 21:46:48',2,'No Beacon'),(6,10,NULL,NULL,NULL,2,'2015-12-27 09:30:22','2016-04-29 21:51:24',1,'CH-DI-DFWD'),(7,NULL,7,NULL,NULL,1,'2015-12-28 05:58:35','2016-04-29 21:51:24',2,'No-Beacon'),(8,10,NULL,NULL,NULL,5,'2015-12-28 17:18:04','2016-04-29 21:51:24',1,'CH-DI-DFWD'),(9,13,NULL,NULL,NULL,5,'2015-12-28 23:37:15','2016-04-29 21:51:24',1,'US-f2@-@3'),(10,NULL,11,NULL,NULL,5,'2015-12-28 23:38:58','2016-04-29 21:51:24',1,'US-CS-SFR'),(11,14,NULL,NULL,NULL,2,'2015-12-31 08:20:25','2016-04-29 21:51:24',1,'US-f2@-@3'),(12,13,NULL,NULL,NULL,2,'2016-01-02 08:22:09','2016-04-29 21:51:24',1,'US-f2@-@3'),(13,8,NULL,NULL,NULL,2,'2016-01-02 08:22:17','2016-04-29 21:51:24',1,'US-SW-ACE'),(14,NULL,14,NULL,NULL,1,'2016-01-02 08:43:24','2016-04-29 21:51:24',2,'US-CS-SFW'),(15,NULL,10,NULL,NULL,1,'2016-01-02 08:43:27','2016-04-29 21:51:24',2,'US-CS-SFW'),(16,NULL,9,NULL,NULL,1,'2016-01-02 08:43:31','2016-04-29 21:51:24',2,'US-CS-SFW'),(17,12,NULL,NULL,NULL,1,'2016-01-02 08:44:01','2016-04-29 21:51:24',2,'No-Beacon'),(18,NULL,3,NULL,NULL,2,'2016-01-02 08:45:11','2016-04-29 21:46:48',1,'No Beacon'),(19,NULL,4,NULL,NULL,2,'2016-01-02 08:45:16','2016-04-29 21:51:24',1,'US-CS-SFR'),(20,NULL,5,NULL,NULL,2,'2016-01-02 08:45:19','2016-04-29 21:46:48',1,'No Beacon'),(22,18,NULL,NULL,NULL,2,'2016-01-11 07:05:05','2016-04-29 21:51:24',1,'CH-DI-DFWD'),(23,16,NULL,NULL,NULL,1,'2016-01-14 02:46:38','2016-04-29 21:51:24',2,'US-CS-SFW'),(24,19,NULL,NULL,NULL,2,'2016-01-15 07:55:29','2016-04-29 21:51:24',1,'CH-DI-DFWD'),(25,20,NULL,NULL,NULL,2,'2016-01-15 22:49:28','2016-04-29 21:51:24',5,'US-CS-SFW'),(26,27,NULL,NULL,NULL,1,'2016-01-20 06:43:03','2016-04-29 21:51:24',6,'No-Beacon'),(27,19,NULL,NULL,NULL,1,'2016-01-26 04:18:41','2016-04-29 21:51:24',1,'CH-DI-DFWD'),(28,19,NULL,NULL,NULL,6,'2016-01-26 07:45:25','2016-04-29 21:51:24',1,'CH-DI-DFWD'),(29,NULL,29,NULL,NULL,2,'2016-01-26 07:48:25','2016-04-29 21:51:24',1,'US-CS-SFR'),(30,NULL,38,NULL,NULL,6,'2016-01-27 00:30:46','2016-04-29 21:51:24',2,'US-CS-SFW'),(31,19,NULL,NULL,NULL,2,'2016-01-27 00:46:26','2016-04-29 21:51:24',1,'CH-DI-DFWD'),(32,NULL,55,NULL,NULL,2,'2016-01-27 00:54:03','2016-04-29 21:51:24',6,'No-Beacon'),(33,NULL,53,NULL,NULL,2,'2016-01-27 01:00:50','2016-04-29 21:51:24',6,'No-Beacon'),(34,NULL,NULL,5,NULL,6,'2016-01-27 07:45:45','2016-04-29 21:46:48',1,'No-Beacon'),(35,1,NULL,NULL,NULL,5,'2016-01-27 09:39:44','2016-04-29 21:46:48',2,'No Beacon'),(36,33,NULL,NULL,NULL,1,'2016-01-28 02:51:41','2016-04-29 21:51:24',2,'US-CS-SFW'),(37,NULL,NULL,5,NULL,1,'2016-01-28 02:52:30','2016-04-29 21:46:48',1,'No-Beacon'),(38,30,NULL,NULL,NULL,1,'2016-01-29 23:52:11','2016-04-29 21:51:24',2,'US-CS-SFW'),(39,NULL,66,NULL,NULL,1,'2016-01-29 23:56:52','2016-04-29 21:51:24',2,'US-CS-SFW'),(40,NULL,69,NULL,NULL,6,'2016-01-30 00:28:35','2016-04-29 21:51:24',1,'US-SW-ACE'),(41,NULL,NULL,6,NULL,1,'2016-02-06 06:50:06','2016-04-29 21:46:48',2,'No-Beacon'),(42,NULL,NULL,6,NULL,5,'2016-02-06 07:59:42','2016-04-29 21:46:48',2,'No-Beacon'),(43,NULL,NULL,6,NULL,2,'2016-02-06 08:01:13','2016-04-29 21:46:48',2,'No-Beacon'),(44,30,NULL,NULL,NULL,6,'2016-02-14 06:38:14','2016-04-29 21:51:24',2,'US-CS-SFW'),(45,NULL,82,NULL,NULL,2,'2016-02-14 06:55:00','2016-04-29 21:51:24',1,'US-SW-ACE'),(46,32,NULL,NULL,NULL,1,'2016-02-14 07:11:26','2016-04-29 21:51:24',5,'US-CS-SFW'),(47,NULL,NULL,9,NULL,1,'2016-02-14 07:13:43','2016-04-29 21:46:48',1,'No-Beacon'),(48,NULL,NULL,9,NULL,6,'2016-02-14 07:21:05','2016-04-29 21:46:48',1,'No-Beacon'),(49,NULL,NULL,6,NULL,6,'2016-02-14 07:21:09','2016-04-29 21:46:48',2,'No-Beacon'),(50,35,NULL,NULL,NULL,1,'2016-02-14 07:23:48','2016-04-29 21:51:24',6,'No-Beacon'),(51,40,NULL,NULL,NULL,2,'2016-02-16 07:27:15','2016-04-29 21:51:24',1,'No-Beacon'),(52,NULL,95,NULL,NULL,1,'2016-02-17 06:08:51','2016-04-29 21:51:24',2,'US-SW-ACE'),(53,41,NULL,NULL,NULL,6,'2016-02-17 07:08:07','2016-04-29 21:51:24',2,'US-SW-ACE'),(54,33,NULL,NULL,NULL,6,'2016-02-17 07:08:12','2016-04-29 21:51:24',2,'US-CS-SFW'),(55,43,NULL,NULL,NULL,2,'2016-02-19 09:31:31','2016-04-29 21:51:24',1,'No-Beacon'),(56,45,NULL,NULL,NULL,8,'2016-02-24 03:34:12','2016-04-29 21:51:24',1,'No-Beacon'),(57,NULL,112,NULL,NULL,8,'2016-02-24 03:34:55','2016-04-29 21:51:24',1,'US-CS-SFR'),(58,NULL,4,NULL,NULL,8,'2016-02-25 05:32:18','2016-04-29 21:51:24',1,'US-CS-SFR'),(59,NULL,11,NULL,NULL,8,'2016-02-25 05:33:33','2016-04-29 21:51:24',1,'US-CS-SFR'),(60,41,NULL,NULL,NULL,8,'2016-02-25 06:16:06','2016-04-29 21:51:24',2,'US-SW-ACE'),(61,NULL,115,NULL,NULL,1,'2016-02-25 20:09:02','2016-04-29 21:51:24',8,'US-CS-SFR'),(62,NULL,116,NULL,NULL,1,'2016-02-25 20:09:07','2016-04-29 21:51:24',8,'US-CS-SFR'),(63,49,NULL,NULL,NULL,2,'2016-02-25 20:31:56','2016-04-29 21:51:24',1,'US-SW-IHOM2'),(64,49,NULL,NULL,NULL,8,'2016-02-25 20:42:25','2016-04-29 21:51:24',1,'US-SW-IHOM2'),(65,40,NULL,NULL,NULL,8,'2016-02-25 20:51:04','2016-04-29 21:51:24',1,'No-Beacon'),(66,36,NULL,NULL,NULL,8,'2016-02-25 20:58:15','2016-04-29 21:51:24',1,'US-SW-ACE'),(67,49,NULL,NULL,NULL,6,'2016-02-25 20:58:33','2016-04-29 21:51:24',1,'US-SW-IHOM2'),(68,NULL,116,NULL,NULL,6,'2016-02-25 21:16:43','2016-04-29 21:51:24',8,'US-CS-SFR'),(69,NULL,115,NULL,NULL,6,'2016-02-25 21:16:53','2016-04-29 21:51:24',8,'US-CS-SFR'),(70,NULL,95,NULL,NULL,6,'2016-02-25 21:17:04','2016-04-29 21:51:24',2,'US-SW-ACE'),(72,NULL,NULL,21,NULL,1,'2016-02-28 04:42:13','2016-04-29 21:46:48',8,'No-Beacon'),(73,NULL,NULL,24,NULL,1,'2016-02-28 04:51:35','2016-04-29 21:46:48',8,'No-Beacon'),(74,NULL,NULL,24,NULL,2,'2016-02-28 18:18:58','2016-04-29 21:46:48',8,'No-Beacon'),(75,51,NULL,NULL,NULL,1,'2016-03-23 05:28:53','2016-04-29 21:51:24',2,'Us-FD-FW'),(76,53,NULL,NULL,NULL,2,'2016-03-25 05:30:10','2016-04-29 21:51:24',1,'US-SW-IHOM2'),(77,54,NULL,NULL,NULL,1,'2016-03-28 23:40:41','2016-04-29 21:51:24',2,'US-SW-ACE'),(78,50,NULL,NULL,NULL,2,'2016-03-30 09:34:27','2016-04-29 21:51:24',14,'No-Beacon'),(79,58,NULL,NULL,NULL,20,'2016-04-07 07:01:37','2016-04-29 21:51:24',17,'No-Beacon'),(80,NULL,NULL,25,NULL,20,'2016-04-07 07:07:00','2016-04-29 21:46:48',17,'No-Beacon'),(81,NULL,NULL,25,NULL,20,'2016-04-07 20:15:27','2016-04-29 21:46:48',20,'No-Beacon'),(82,56,NULL,NULL,NULL,20,'2016-04-07 20:15:32','2016-04-29 21:51:24',1,'US-SW-IHOM2'),(83,NULL,147,NULL,NULL,20,'2016-04-07 22:23:26','2016-04-29 21:51:24',20,'No-Beacon'),(84,NULL,NULL,25,NULL,20,'2016-04-07 22:49:43','2016-04-29 21:46:48',20,'No-Beacon'),(85,60,NULL,NULL,NULL,1,'2016-04-11 00:18:06','2016-04-29 21:51:24',20,'No-Beacon'),(86,NULL,151,NULL,NULL,8,'2016-04-11 05:21:05','2016-04-29 21:51:24',20,'No-Beacon'),(87,NULL,151,NULL,NULL,1,'2016-04-11 05:46:38','2016-04-29 21:51:24',20,'No-Beacon'),(88,NULL,144,NULL,NULL,1,'2016-04-11 07:58:19','2016-04-29 21:51:24',20,'US-CS-SFR'),(89,68,NULL,NULL,NULL,31,'2016-04-12 06:59:50','2016-04-29 21:51:24',20,'No-Beacon'),(90,70,NULL,NULL,NULL,1,'2016-04-15 04:46:02','2016-04-29 21:51:24',31,'No-Beacon'),(91,NULL,150,NULL,NULL,1,'2016-04-15 04:57:00','2016-04-29 21:51:24',20,'No-Beacon'),(92,NULL,NULL,25,NULL,1,'2016-04-18 05:37:26','2016-04-29 21:46:48',20,'No-Beacon'),(93,71,NULL,NULL,NULL,33,'2016-04-18 07:29:59','2016-04-29 21:51:24',1,'US-SA-HASDF'),(94,NULL,NULL,25,NULL,33,'2016-04-18 07:30:35','2016-04-29 21:46:48',20,'No-Beacon'),(95,NULL,162,NULL,NULL,1,'2016-04-27 00:10:15','2016-04-29 21:51:24',8,'US-SW-23'),(96,NULL,168,NULL,NULL,1,'2016-04-28 07:13:29','2016-04-29 21:51:24',33,'No-Beacon'),(97,82,NULL,NULL,NULL,33,'2016-04-28 07:24:10','2016-04-29 21:51:24',1,'US-SW-IHOM2'),(98,80,NULL,NULL,NULL,33,'2016-04-28 07:25:16','2016-04-29 21:51:24',29,'US-SW-23'),(99,49,NULL,NULL,NULL,33,'2016-04-29 21:32:33','2016-04-29 21:51:24',1,'US-SW-IHOM2'),(100,85,NULL,NULL,NULL,1,'2016-04-29 22:06:03','2016-04-29 22:06:03',33,'US-BLR-HPCC'),(101,86,NULL,NULL,NULL,33,'2016-04-30 06:49:41','2016-04-30 06:49:41',1,'IT-FLR-Duomo'),(102,84,NULL,NULL,NULL,33,'2016-04-30 06:50:12','2016-04-30 06:50:12',1,'IT-FLR-BOSC'),(103,68,NULL,NULL,NULL,1,'2016-05-02 05:22:07','2016-05-02 05:22:07',20,'No-Beacon'),(104,81,NULL,NULL,NULL,1,'2016-05-02 05:54:21','2016-05-02 05:54:21',33,'No-Beacon'),(105,58,NULL,NULL,NULL,1,'2016-05-02 06:01:42','2016-05-02 06:01:42',20,'No-Beacon'),(106,88,NULL,NULL,NULL,1,'2016-05-02 06:16:23','2016-05-02 06:16:23',15,'IT-FLR-BOSC'),(107,NULL,147,NULL,NULL,1,'2016-05-02 06:20:06','2016-05-02 06:20:06',20,'No-Beacon'),(108,NULL,173,NULL,NULL,1,'2016-05-02 07:48:50','2016-05-02 07:48:50',33,'IT-FLR-Duomo'),(109,90,NULL,NULL,NULL,1,'2016-05-09 06:45:12','2016-05-09 06:45:12',2,'IT-FLR-Duomo'),(110,92,NULL,NULL,NULL,33,'2016-05-11 21:38:23','2016-05-11 21:38:23',1,'US-SW-HOSF'),(111,95,NULL,NULL,NULL,1,'2016-05-15 21:46:56','2016-05-15 21:46:56',35,'US-SW-Idea'),(112,NULL,NULL,30,NULL,1,'2016-05-16 07:50:06','2016-05-16 07:50:06',1,'No-Beacon');
/*!40000 ALTER TABLE `elevations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extensions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `belief` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `beacon_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nymified` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extension_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `source_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `extenception` int(10) unsigned DEFAULT NULL,
  `question_id` int(10) unsigned DEFAULT NULL,
  `legacy_post_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  `elevation` int(10) unsigned NOT NULL,
  `extension` int(10) unsigned NOT NULL,
  `source_user` int(10) unsigned NOT NULL,
  `status` tinyint(3) unsigned DEFAULT NULL,
  `lat` double(10,6) DEFAULT NULL,
  `long` double(10,6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `extensions_user_id_foreign` (`user_id`),
  CONSTRAINT `extensions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `extensions` WRITE;
/*!40000 ALTER TABLE `extensions` DISABLE KEYS */;
INSERT INTO `extensions` VALUES (1,'My zoko extension from amaricus','Adaptia','No Beacon','Opinion',NULL,'/extensions/1/My zoko extension from amaricus.txt','',1,NULL,NULL,NULL,'2015-12-20 08:20:32','2015-12-21 07:19:53',1,1,1,2,NULL,NULL,NULL),(2,'zoko\'s extension of amaricus','Atheism','PH-CEB-CMC','Speech',NULL,'/extensions/2/zoko\'s extension of amaricus.txt','',1,1,NULL,NULL,'2015-12-20 08:21:28','2015-12-21 02:10:03',2,1,0,1,NULL,NULL,NULL),(3,'my new extension','Adaptia','No Beacon','Opinion',NULL,'/extensions/1/my new extension.txt','',1,1,NULL,NULL,'2015-12-21 07:19:53','2016-01-02 08:45:11',1,1,0,1,NULL,NULL,NULL),(4,'now a new one!','Adaptia','US-CS-SFR','Post',NULL,'/posts/1/now a new one!.txt','',5,NULL,NULL,NULL,'2015-12-22 05:14:29','2016-04-21 18:31:19',1,2,1,1,NULL,NULL,NULL),(5,'My new extension of this','Buddhism','No Beacon','Poem',NULL,'/posts/1/My new extension of this.txt','',5,4,NULL,NULL,'2015-12-22 08:36:59','2016-01-02 08:45:19',1,1,1,1,NULL,NULL,NULL),(6,'another extension','Adaptia','US-SW-ACE','Opinion',NULL,'/extensions/1/another extension.txt','',5,5,NULL,NULL,'2015-12-27 09:27:51','2015-12-27 09:27:51',1,0,0,1,NULL,NULL,NULL),(7,'my extension of amaricus','Ba Gua','No-Beacon','Poem',NULL,'/extensions/2/my extension of amaricus.txt','',10,NULL,NULL,NULL,'2015-12-27 09:30:36','2015-12-28 05:58:35',2,1,0,1,NULL,NULL,NULL),(8,'my first zagmail extension','Ba Gua','No-Beacon','Prayer',NULL,'/extensions/5/my first zagmail extension.txt','',10,NULL,NULL,NULL,'2015-12-28 17:18:22','2016-01-27 08:36:24',5,0,0,1,1,NULL,NULL),(9,'this is my first extension','Adaptia','US-CS-SFW','Opinion',NULL,'/extensions/2/this is my first extension.txt','',11,NULL,NULL,NULL,'2015-12-28 23:17:06','2016-01-02 08:43:31',2,1,2,5,NULL,NULL,NULL),(10,'my first bigger extension baby2','Atheism','US-CS-SFW','Poem',NULL,'/extensions/2/my first bigger extension baby2.txt','',11,9,NULL,NULL,'2015-12-28 23:35:12','2016-01-02 08:43:27',2,1,0,2,NULL,NULL,NULL),(11,'My post extension','Ba Gua','US-CS-SFR','Post',NULL,'/posts/1/My post extension.txt','',13,NULL,NULL,NULL,'2015-12-28 23:36:55','2016-04-15 19:11:08',1,2,1,1,NULL,NULL,NULL),(12,'My zagmail extension','Buddhism','US-CS-SFW','Opinion',NULL,'/extensions/5/My zagmail extension.txt','',13,NULL,NULL,NULL,'2015-12-28 23:37:38','2015-12-28 23:37:38',5,0,0,1,NULL,NULL,NULL),(13,'My extension of your extension','Adaptia','US-CS-SFW','Opinion',NULL,'/extensions/5/My extension of your extension.txt','',13,11,NULL,NULL,'2015-12-28 23:39:12','2015-12-28 23:39:12',5,0,0,1,NULL,NULL,NULL),(14,'whatcha know about that!','Adaptia','US-CS-SFW','Opinion',NULL,'/extensions/2/whatcha know about that!.txt','',14,NULL,NULL,NULL,'2015-12-31 08:20:42','2016-01-02 08:43:24',2,1,0,1,NULL,NULL,NULL),(15,'my extension','Adaptia','US-SW-ACE','Opinion',NULL,'/extensions/1/my extension.txt','',12,NULL,NULL,NULL,'2016-01-03 06:16:28','2016-01-03 06:16:28',1,0,0,2,NULL,NULL,NULL),(16,'testing','Ba Gua','US-IS-022','Post',NULL,'/posts/1/testing.txt','',18,NULL,NULL,NULL,'2016-01-11 07:04:30','2016-03-24 19:57:06',1,0,0,1,NULL,NULL,NULL),(17,'my first of yours','Adaptia','US-SW-ACE','Prayer',NULL,'/extensions/1/my first of yours.txt','',16,NULL,NULL,NULL,'2016-01-14 02:46:48','2016-01-14 02:46:48',1,0,0,2,NULL,NULL,NULL),(18,'this is my extension','Indigenous','US-CS-SFW','Opinion',NULL,'/extensions/2/this is my extension.txt','',21,NULL,NULL,NULL,'2016-01-15 22:49:12','2016-01-15 22:49:12',2,0,0,2,NULL,NULL,NULL),(19,'this is a test','Druze','US-CS-SFW','Poem',NULL,'/posts/2/this is a test.txt','',23,NULL,NULL,NULL,'2016-01-20 03:19:16','2016-01-20 04:08:08',2,0,0,2,NULL,NULL,NULL),(20,'my test extension email','Buddhism','US-CS-SFW','Prayer',NULL,'/extensions/2/my test extension email.txt','',26,NULL,NULL,NULL,'2016-01-20 06:25:17','2016-01-20 06:25:17',2,0,0,1,NULL,NULL,NULL),(21,'my second extension','Atheism','US-CS-SFW','Opinion',NULL,'/extensions/2/my second extension.txt','',26,NULL,NULL,NULL,'2016-01-20 06:27:47','2016-01-20 06:27:47',2,0,0,1,NULL,NULL,NULL),(22,'my third extension','Atheism','US-CS-SFW','Opinion',NULL,'/extensions/2/my third extension.txt','',26,NULL,NULL,NULL,'2016-01-20 06:29:52','2016-01-20 06:29:52',2,0,0,1,NULL,NULL,NULL),(23,'My first big extension','Urantia','No-Beacon','Other',NULL,'/extensions/6/My first big extension.txt','',26,NULL,NULL,NULL,'2016-01-20 06:40:24','2016-01-20 06:40:24',6,0,0,1,NULL,NULL,NULL),(24,'This is an extension','Ba Gua','US-CS-SFR','Prayer',NULL,'/extensions/1/This is an extension.txt','',27,NULL,NULL,NULL,'2016-01-20 06:43:19','2016-01-20 06:43:19',1,0,0,6,NULL,NULL,NULL),(25,'Another big extension','Ba Gua','No-Beacon','Poem',NULL,'/extensions/1/Another big extension.txt','',27,NULL,NULL,NULL,'2016-01-20 06:53:12','2016-05-18 23:29:25',1,0,0,6,NULL,NULL,NULL),(26,'my tester','Buddhism','No-Beacon','Poem',NULL,'/extensions/1/my tester.txt','',27,NULL,NULL,NULL,'2016-01-20 07:05:40','2016-05-18 23:29:25',1,0,0,6,NULL,NULL,NULL),(27,'my test','Atheism','No-Beacon','Opinion',NULL,'/posts/6/my test.txt','',27,NULL,NULL,NULL,'2016-01-22 17:22:00','2016-01-22 17:23:10',6,0,0,6,NULL,NULL,NULL),(28,'my test7','Atheism','No-Beacon','Poem',NULL,'/extensions/1/my test7.txt','',NULL,NULL,5,NULL,'2016-01-25 12:02:16','2016-05-18 23:29:25',1,0,0,1,NULL,NULL,NULL),(29,'my first extension','Ba Gua','US-CS-SFR','Question',NULL,'/posts/1/my first extension.txt','',NULL,NULL,5,NULL,'2016-01-25 12:06:36','2016-02-25 20:16:57',1,1,9,1,NULL,NULL,NULL),(30,'my extension of teste2','Atheism','US-SW-ACE','Poem',NULL,'/extensions/1/my extension of teste2.txt','',28,NULL,NULL,NULL,'2016-01-25 12:08:10','2016-01-25 12:08:10',1,0,0,6,NULL,NULL,NULL),(31,'tester ','Atheism','US-SW-ACE','Poem',NULL,'/extensions/1/tester .txt','',NULL,29,NULL,NULL,'2016-01-26 05:58:30','2016-01-26 05:58:30',1,0,0,1,NULL,NULL,NULL),(32,'tester 7','Atheism','US-SW-ACE','Poem',NULL,'/extensions/1/tester 7.txt','',NULL,29,NULL,NULL,'2016-01-26 05:59:30','2016-01-26 05:59:30',1,0,0,1,NULL,NULL,NULL),(33,'Asdfasdf','Adaptia','US-SW-ACE','Poem',NULL,'/extensions/1/Asdfasdf.txt','',28,NULL,NULL,NULL,'2016-01-26 06:00:41','2016-01-27 19:27:59',1,0,1,6,NULL,NULL,NULL),(34,'masdfa','Ba Gua','US-SW-ACE','Opinion',NULL,'/extensions/1/masdfa.txt','',NULL,29,NULL,NULL,'2016-01-26 06:01:45','2016-01-26 06:01:45',1,0,0,1,NULL,NULL,NULL),(35,'My extension of this question','Ba Gua','No-Beacon','Poem',NULL,'/extensions/6/My extension of this question.txt','',NULL,NULL,5,NULL,'2016-01-26 07:47:35','2016-01-26 07:47:35',6,0,0,1,NULL,NULL,NULL),(36,'My extension of your question','Sikhism','US-CS-SFW','Poem',NULL,'/extensions/2/My extension of your question.txt','',NULL,29,NULL,NULL,'2016-01-26 07:48:43','2016-01-26 07:48:43',2,0,0,1,NULL,NULL,NULL),(37,'My extension of your question4','Sikhism','US-CS-SFW','Poem',NULL,'/extensions/2/My extension of your question4.txt','',NULL,29,NULL,NULL,'2016-01-26 07:51:29','2016-01-26 07:51:29',2,0,0,1,NULL,NULL,NULL),(38,'My extension of your question44','Sikhism','US-CS-SFW','Poem',NULL,'/extensions/2/My extension of your question44.txt','',NULL,29,5,NULL,'2016-01-26 07:55:20','2016-01-27 00:38:36',2,1,1,1,NULL,NULL,NULL),(39,'this is asfasdf','Druze','US-CS-SFW','Poem',NULL,'/extensions/2/this is asfasdf.txt','',NULL,29,NULL,NULL,'2016-01-26 07:55:48','2016-01-26 07:55:48',2,0,0,1,NULL,NULL,NULL),(40,'this is asfasdf77','Druze','US-CS-SFW','Poem',NULL,'/extensions/2/this is asfasdf77.txt','',NULL,29,NULL,NULL,'2016-01-26 07:56:40','2016-01-26 07:56:40',2,0,0,1,NULL,NULL,NULL),(41,'this si my tester','Adaptia','No-Beacon','Poem',NULL,'/extensions/6/this si my tester.txt','',29,NULL,NULL,NULL,'2016-01-26 23:35:22','2016-01-26 23:38:07',6,0,1,1,NULL,NULL,NULL),(42,'more extension test7','Buddhism','No-Beacon','Prayer',NULL,'/extensions/6/more extension test7.txt','',29,41,NULL,NULL,'2016-01-26 23:38:07','2016-01-26 23:38:07',6,0,0,6,NULL,NULL,NULL),(43,'My extension of this quesiton','Ba Gua','No-Beacon','Prayer',NULL,'/extensions/6/My extension of this quesiton.txt','',NULL,NULL,5,NULL,'2016-01-26 23:38:32','2016-01-26 23:44:18',6,0,4,1,NULL,NULL,NULL),(44,'This is also my question extension','Druze','No-Beacon','Reflection',NULL,'/extensions/6/This is also my question extension.txt','',NULL,43,NULL,NULL,'2016-01-26 23:38:49','2016-01-26 23:38:49',6,0,0,6,NULL,NULL,NULL),(45,'This is also my question extension2','Druze','No-Beacon','Reflection',NULL,'/extensions/6/This is also my question extension2.txt','',NULL,43,NULL,NULL,'2016-01-26 23:39:59','2016-01-26 23:39:59',6,0,0,6,NULL,NULL,NULL),(46,'This is also my question extension27','Druze','No-Beacon','Reflection',NULL,'/extensions/6/This is also my question extension27.txt','',NULL,43,5,NULL,'2016-01-26 23:41:30','2016-01-26 23:41:30',6,0,0,6,NULL,NULL,NULL),(47,'This is also my question extension270','Druze','No-Beacon','Reflection',NULL,'/extensions/6/This is also my question extension270.txt','',NULL,NULL,NULL,NULL,'2016-01-26 23:44:18','2016-01-26 23:44:18',6,0,0,0,NULL,NULL,NULL),(48,'This is also my question extension2709','Druze','No-Beacon','Poem',NULL,'/extensions/6/This is also my question extension2709.txt','',NULL,NULL,NULL,NULL,'2016-01-27 00:06:54','2016-01-27 00:06:54',6,0,0,0,NULL,NULL,NULL),(49,'Asdfasdf','Atheism','No-Beacon','Poem',NULL,'/extensions/6/Asdfasdf.txt','',29,NULL,NULL,NULL,'2016-01-27 00:15:58','2016-01-27 00:15:58',6,0,0,1,NULL,NULL,NULL),(50,'another extension','Ba Gua','No-Beacon','Poem',NULL,'/extensions/6/another extension.txt','',29,NULL,NULL,NULL,'2016-01-27 00:19:43','2016-01-27 00:21:36',6,0,1,1,NULL,NULL,NULL),(51,'my big poster','Ba Gua','No-Beacon','Prayer',NULL,'/extensions/6/my big poster.txt','',29,50,NULL,NULL,'2016-01-27 00:21:36','2016-01-27 00:21:36',6,0,0,6,NULL,NULL,NULL),(52,'my big extension of this','Christianity','No-Beacon','Prayer',NULL,'/extensions/6/my big extension of this.txt','',NULL,NULL,5,NULL,'2016-01-27 00:23:28','2016-02-17 01:03:54',6,0,2,1,NULL,NULL,NULL),(53,'my weekly extension of question','Buddhism','No-Beacon','Poem',NULL,'/extensions/6/my weekly extension of question.txt','',NULL,52,5,NULL,'2016-01-27 00:26:07','2016-01-27 01:00:50',6,1,0,6,NULL,NULL,NULL),(54,'my extension of this question extension','Atheism','No-Beacon','Poem',NULL,'/extensions/6/my extension of this question extension.txt','',NULL,29,5,NULL,'2016-01-27 00:35:36','2016-01-27 00:35:36',6,0,0,1,NULL,NULL,NULL),(55,'another extensionf for you','Ba Gua','No-Beacon','Poem',NULL,'/extensions/6/another extensionf for you.txt','',NULL,38,5,NULL,'2016-01-27 00:38:36','2016-01-27 00:54:18',6,1,1,2,NULL,NULL,NULL),(56,'This is my first big extension','Buddhism','US-CS-SFW','Prayer',NULL,'/extensions/2/This is my first big extension.txt','',NULL,NULL,5,NULL,'2016-01-27 00:49:05','2016-01-27 00:49:05',2,0,0,1,NULL,NULL,NULL),(57,'Another extension boy','Buddhism','US-SW-IHOM2','Poem',NULL,'/extensions/2/Another extension boy.txt','',NULL,NULL,5,NULL,'2016-01-27 00:49:31','2016-01-27 00:49:31',2,0,0,1,NULL,NULL,NULL),(58,'My extension of youd question','Atheism','US-CS-SFW','Prayer',NULL,'/extensions/2/My extension of youd question.txt','',NULL,55,5,NULL,'2016-01-27 00:54:18','2016-01-27 19:18:48',2,0,1,6,NULL,NULL,NULL),(59,'my extension of this post','Ba Gua','US-CS-SFW','Poem',NULL,'/extensions/2/my extension of this post.txt','',30,NULL,NULL,NULL,'2016-01-27 00:58:32','2016-01-27 00:58:32',2,0,0,2,NULL,NULL,NULL),(60,'my extension of this poster','Ba Gua','No-Beacon','Poem',NULL,'/extensions/6/my extension of this poster.txt','',31,NULL,NULL,NULL,'2016-01-27 07:36:03','2016-01-27 07:36:03',6,0,0,6,NULL,NULL,NULL),(61,'my esf','Christianity','US-CS-SFW','Prayer',NULL,'/extensions/5/my esf.txt','',32,NULL,NULL,NULL,'2016-01-27 09:39:37','2016-01-27 09:39:37',5,0,0,5,NULL,NULL,NULL),(62,'extension test dup','Ba Gua','No-Beacon','Poem',NULL,'/extensions/6/extension test dup.txt','',28,NULL,NULL,NULL,'2016-01-27 19:18:05','2016-01-27 19:18:05',6,0,0,6,NULL,NULL,NULL),(63,'my ext quesiont test','Christianity','No-Beacon','Poem',NULL,'/extensions/6/my ext quesiont test.txt','',NULL,58,5,NULL,'2016-01-27 19:18:48','2016-01-27 19:21:54',6,0,1,2,NULL,NULL,NULL),(64,'My question extensions boh','Christianity','No-Beacon','Poem',NULL,'/extensions/6/My question extensions boh.txt','',NULL,63,5,NULL,'2016-01-27 19:21:54','2016-01-27 19:21:54',6,0,0,6,NULL,NULL,NULL),(65,'my tester of this booosh','Ba Gua','US-CS-SFW','Poem',NULL,'/extensions/2/my tester of this booosh.txt','',28,33,NULL,NULL,'2016-01-27 19:27:59','2016-01-27 19:27:59',2,0,0,1,NULL,NULL,NULL),(66,'my second draft of this','Christianity','US-CS-SFW','Prayer',NULL,'/extensions/2/my second draft of this.txt','',24,NULL,NULL,NULL,'2016-01-27 19:30:05','2016-01-29 23:56:52',2,1,0,2,NULL,NULL,NULL),(67,'my first extension2','Buddhism','US-SW-ACE','Poem',NULL,'/posts/1/my first extension2.txt','',33,NULL,NULL,NULL,'2016-01-28 02:51:53','2016-01-28 02:52:23',1,0,0,2,NULL,NULL,NULL),(68,'this si my question extension','Christianity','US-SW-ACE','Reflection',NULL,'/extensions/1/this si my question extension.txt','',NULL,NULL,5,NULL,'2016-01-28 02:52:42','2016-01-28 02:52:54',1,0,1,1,NULL,NULL,NULL),(69,'question extension','Ba Gua','US-SW-ACE','Reflection',NULL,'/extensions/1/question extension.txt','',NULL,68,5,NULL,'2016-01-28 02:52:54','2016-04-02 22:46:31',1,1,1,1,1,NULL,NULL),(70,'tasdfasdfasdf','Buddhism','US-SW-ACE','Poem',NULL,'/extensions/1/tasdfasdfasdf.txt','',34,NULL,NULL,NULL,'2016-01-29 01:17:43','2016-02-04 06:40:42',1,0,1,1,NULL,NULL,NULL),(71,'This is my extension of the prayer','Christianity','No-Beacon','Reflection',NULL,'/extensions/6/This is my extension of the prayer.txt','',35,NULL,NULL,NULL,'2016-01-30 00:28:06','2016-01-30 00:28:06',6,0,0,6,NULL,NULL,NULL),(72,'What I know about this','Buddhism','No-Beacon','Opinion',NULL,'/posts/6/What I know about this.txt','',NULL,69,5,NULL,'2016-01-30 00:29:00','2016-02-14 03:51:05',6,0,1,1,NULL,NULL,NULL),(73,'My extensionasdf','Urantia','US-SW-ACE','Poem',NULL,'/posts/1/My extensionasdf.txt','',NULL,NULL,5,NULL,'2016-01-30 00:56:15','2016-02-16 22:20:12',1,0,1,1,NULL,NULL,NULL),(74,'This is my first extension','Buddhism','No-Beacon','Opinion',NULL,'/posts/1/This is my first extension.txt','',NULL,NULL,6,NULL,'2016-02-02 17:47:34','2016-05-18 23:36:51',1,0,1,2,NULL,NULL,NULL),(75,'This is another cool','Buddhism','US-SW-ACE','Poem',NULL,'/extensions/1/This is another cool.txt','',NULL,74,6,NULL,'2016-02-02 17:47:49','2016-02-02 17:47:49',1,0,0,1,NULL,NULL,NULL),(76,'whatcha know about that!','Hinduism','US-SW-ACE','Reflection',NULL,'/extensions/1/whatcha know about that!.txt','',NULL,72,5,NULL,'2016-02-02 18:10:46','2016-02-02 18:10:46',1,0,0,6,NULL,NULL,NULL),(77,'My test of your in','Ba Gua','No-Beacon','Opinion',NULL,'/posts/6/My test of your in.txt','',34,70,NULL,NULL,'2016-02-04 06:40:42','2016-02-14 03:49:43',6,0,0,1,NULL,NULL,NULL),(78,'This question is kinda good','Christianity','No-Beacon','Scripture',NULL,'/posts/6/This question is kinda good.txt','',NULL,NULL,6,NULL,'2016-02-06 06:59:01','2016-02-13 09:11:20',6,0,1,2,NULL,NULL,NULL),(79,'my extensionasdf','Ba Gua','US-SW-ACE','Poem',NULL,'/extensions/1/my extensionasdf.txt','',NULL,78,6,NULL,'2016-02-06 07:03:56','2016-02-14 06:58:06',1,0,1,6,NULL,NULL,NULL),(80,'asdfasdf','Ba Gua','PH-HID-D323','Reflection',NULL,'/extensions/5/asdfasdf.txt','',NULL,NULL,6,NULL,'2016-02-06 07:59:51','2016-02-06 07:59:51',5,0,0,2,NULL,NULL,NULL),(81,'my testasdf','Christianity','US-CS-SFW','Other',NULL,'/extensions/2/my testasdf.txt','',NULL,NULL,6,NULL,'2016-02-06 08:01:23','2016-02-06 08:01:23',2,0,0,2,NULL,NULL,NULL),(82,'asdfasdf2','Atheism','US-SW-ACE','Poem',NULL,'/extensions/1/asdfasdf2.txt','',37,NULL,NULL,NULL,'2016-02-13 09:17:36','2016-02-14 07:11:04',1,1,1,6,NULL,NULL,NULL),(83,'test of noti','Atheism','US-CS-SFW','Poem',NULL,'/extensions/2/test of noti.txt','',33,NULL,NULL,NULL,'2016-02-14 06:48:39','2016-02-14 06:48:39',2,0,0,2,NULL,NULL,NULL),(84,'test of noti0','Atheism','US-CS-SFW','Poem',NULL,'/extensions/2/test of noti0.txt','',33,NULL,NULL,NULL,'2016-02-14 06:48:55','2016-02-14 06:48:55',2,0,0,2,NULL,NULL,NULL),(85,'My 23 sea','Buddhism','US-SW-7DA','Prayer',NULL,'/extensions/1/My 23 sea.txt','',NULL,79,6,NULL,'2016-02-14 06:58:06','2016-02-14 06:58:06',1,0,0,1,NULL,NULL,NULL),(86,'another big one alith asooo long whatch ','Ba Gua','US-SW-ACE','Poem',NULL,'/extensions/1/another big one alith asooo long whatch .txt','',37,82,NULL,NULL,'2016-02-14 07:11:04','2016-02-14 07:11:04',1,0,0,1,NULL,NULL,NULL),(87,'my tester2','Atheism','US-SW-ACE','Poem',NULL,'/extensions/1/my tester2.txt','',38,NULL,NULL,NULL,'2016-02-14 07:12:33','2016-02-14 07:12:33',1,0,0,1,NULL,NULL,NULL),(88,'my post extension2','Ba Gua','US-SW-ACE','Prayer',NULL,'/extensions/1/my post extension2.txt','',38,NULL,NULL,NULL,'2016-02-14 07:15:05','2016-02-14 07:15:05',1,0,0,1,NULL,NULL,NULL),(89,'asdfasdf','Ba Gua','US-SW-ACE','Prayer',NULL,'/extensions/1/asdfasdf.txt','',39,NULL,NULL,NULL,'2016-02-15 09:32:27','2016-02-15 09:32:27',1,0,0,1,NULL,NULL,NULL),(90,'my extnesion','Buddhism','No-Beacon','Scholar',NULL,'/extensions/2/my extnesion.txt','',40,NULL,NULL,NULL,'2016-02-16 07:27:26','2016-02-16 07:27:26',2,0,0,1,NULL,NULL,NULL),(91,'testasdfasd','Buddhism','US-SW-ACE','Reflection',NULL,'/extensions/2/testasdfasd.txt','',40,NULL,NULL,NULL,'2016-02-16 20:49:11','2016-02-16 20:49:19',2,0,1,1,NULL,NULL,NULL),(92,'asdfasdf','Adaptia','US-SW-ACE','Poem',NULL,'/extensions/2/asdfasdf.txt','',40,91,NULL,NULL,'2016-02-16 20:49:19','2016-02-16 20:49:19',2,0,0,2,NULL,NULL,NULL),(93,'my second text','Buddhism','US-SW-ACE','Poem',NULL,'/extensions/2/my second text.txt','',NULL,73,5,NULL,'2016-02-16 22:20:12','2016-02-16 22:20:12',2,0,0,1,NULL,NULL,NULL),(94,'tester','Atheism','US-SW-ACE','Prayer',NULL,'/extensions/2/tester.txt','',NULL,52,5,NULL,'2016-02-17 01:03:54','2016-02-17 01:03:54',2,0,0,6,NULL,NULL,NULL),(95,'my testasdf2','Adaptia','US-SW-ACE','Idee',NULL,'/posts/2/my testasdf2.txt','',41,NULL,NULL,NULL,'2016-02-17 05:45:12','2016-02-25 21:17:04',2,2,1,2,NULL,NULL,NULL),(96,'My big extension','Adaptia','US-SW-IHOM2','Extension',NULL,'/posts/1/My big extension.txt','',41,95,NULL,NULL,'2016-02-17 06:09:10','2016-02-23 06:25:20',1,0,0,2,NULL,NULL,NULL),(97,'this is my post extension','Atheism','US-SW-ACE','Post',NULL,'/posts/2/this is my post extension.txt','',41,NULL,NULL,NULL,'2016-02-17 06:38:50','2016-02-17 06:50:46',2,0,1,2,NULL,NULL,NULL),(98,'my extension for my Love','Atheism','Us-FD-FW','Extension',NULL,'/extensions/2/my extension for my Love.txt','',41,97,NULL,NULL,'2016-02-17 06:50:46','2016-02-17 06:50:46',2,0,0,2,NULL,NULL,NULL),(99,'my test of this question extension','Buddhism','US-SW-ACE','Question',NULL,'/extensions/2/my test of this question extension.txt','',NULL,NULL,9,NULL,'2016-02-17 06:54:19','2016-02-17 06:54:36',2,0,1,1,NULL,NULL,NULL),(100,'asdfasdfasdfasdf','Adaptia','US-SW-ACE','Extension',NULL,'/extensions/2/asdfasdfasdfasdf.txt','',NULL,99,9,NULL,'2016-02-17 06:54:36','2016-02-17 06:54:36',2,0,0,2,NULL,NULL,NULL),(101,'This is my extension','Shinto','US-SW-7DA','Post',NULL,'/extensions/6/This is my extension.txt','',42,NULL,NULL,NULL,'2016-02-17 07:09:46','2016-02-17 07:10:08',6,0,1,6,NULL,NULL,NULL),(102,'my next extesnion','Adaptia','US-SW-7DA','Extension',NULL,'/extensions/6/my next extesnion.txt','',42,101,NULL,NULL,'2016-02-17 07:10:08','2016-02-17 07:10:22',6,0,1,6,NULL,NULL,NULL),(103,'another extensionas','Buddhism','US-SW-7DA','Extension',NULL,'/extensions/6/another extensionas.txt','',42,102,NULL,NULL,'2016-02-17 07:10:22','2016-02-17 07:10:22',6,0,0,6,NULL,NULL,NULL),(104,'This is great!','Adaptia','US-SW-7DA','Question',NULL,'/extensions/6/This is great!.txt','',NULL,NULL,9,NULL,'2016-02-17 07:10:51','2016-02-17 07:11:06',6,0,1,1,NULL,NULL,NULL),(105,'asasdasdf','Adaptia','US-SW-7DA','Extension',NULL,'/extensions/6/asasdasdf.txt','',NULL,104,9,NULL,'2016-02-17 07:11:06','2016-02-17 07:11:06',6,0,0,6,NULL,NULL,NULL),(106,'my tester of this post','Ba Gua','No-Beacon','Question',NULL,'/posts/5/my tester of this post.txt','',NULL,NULL,9,NULL,'2016-02-18 08:11:02','2016-02-19 10:25:06',5,0,2,1,NULL,NULL,NULL),(107,'asdfasdfasdf','Adaptia','No-Beacon','Extension',NULL,'/extensions/5/asdfasdfasdf.txt','',NULL,106,9,NULL,'2016-02-18 08:11:24','2016-02-18 08:11:24',5,0,0,5,NULL,NULL,NULL),(108,'asdfase2323','Buddhism','US-CS-SFR','Post',NULL,'/posts/1/asdfase2323.txt','',43,NULL,NULL,NULL,'2016-02-19 09:30:21','2016-02-23 02:29:16',1,0,0,1,NULL,NULL,NULL),(109,'This is goclas','Atheism','Us-FD-FW','Post',NULL,'/extensions/2/This is goclas.txt','',43,NULL,NULL,NULL,'2016-02-19 09:31:45','2016-02-19 09:31:45',2,0,0,1,NULL,NULL,NULL),(110,'asdfasdfasd','Atheism','US-SW-ACE','Extension',NULL,'/extensions/2/asdfasdfasd.txt','',NULL,106,9,NULL,'2016-02-19 10:25:06','2016-02-19 10:25:06',2,0,0,5,NULL,NULL,NULL),(111,'My 2as','Atheism','US-CS-SFR','Post',NULL,'/extensions/8/My 2as.txt','',46,NULL,NULL,NULL,'2016-02-23 06:50:45','2016-02-23 06:50:45',8,0,0,8,NULL,NULL,NULL),(112,'My extension of the question','Ba Gua','US-CS-SFR','Question',NULL,'/posts/1/My extension of the question.txt','',NULL,NULL,9,NULL,'2016-02-23 07:05:29','2016-02-25 20:00:31',1,1,1,1,NULL,NULL,NULL),(113,'this is my joyful extension','Ba Gua','US-CS-SFR','Extension',NULL,'/extensions/8/this is my joyful extension.txt','',NULL,112,9,NULL,'2016-02-24 03:35:16','2016-02-24 03:35:16',8,0,0,1,NULL,NULL,NULL),(114,'asdfasdf23','Adaptia','US-CS-SFR','Post',NULL,'/extensions/1/asdfasdf23.txt','',47,NULL,NULL,NULL,'2016-02-24 06:49:41','2016-02-25 04:30:47',1,0,1,1,NULL,NULL,NULL),(115,'My first extension','Ba Gua','US-CS-SFR','Extension',NULL,'/extensions/8/My first extension.txt','',47,114,NULL,NULL,'2016-02-25 04:30:47','2016-02-25 21:16:53',8,2,0,1,NULL,NULL,NULL),(116,'23rasdf','Atheism','US-CS-SFR','Post',NULL,'/extensions/8/23rasdf.txt','',48,NULL,NULL,NULL,'2016-02-25 06:21:38','2016-02-25 21:16:43',8,2,0,8,NULL,NULL,NULL),(117,'this is cool','Adaptia','US-SW-IHOM2','Post',NULL,'/extensions/1/this is cool.txt','',48,NULL,NULL,NULL,'2016-02-25 06:22:12','2016-02-25 06:22:12',1,0,0,8,NULL,NULL,NULL),(118,'Whatcha know about that!','Ba Gua','US-SF-Sdfw','Post',NULL,'/extensions/1/Whatcha know about that!.txt','',40,NULL,NULL,NULL,'2016-02-25 19:18:16','2016-02-25 20:00:46',1,0,1,1,NULL,NULL,NULL),(119,'This is my extension','Buddhism','US-CS-SFR','Extension',NULL,'/extensions/1/This is my extension.txt','',40,118,NULL,NULL,'2016-02-25 20:00:46','2016-02-25 20:00:46',1,0,0,1,NULL,NULL,NULL),(120,'This is 2-25 extensions','Buddhism','Us-FD-FW','Post',NULL,'/extensions/2/This is 2-25 extensions.txt','',49,NULL,NULL,NULL,'2016-02-25 20:32:12','2016-02-25 20:32:12',2,0,0,1,NULL,NULL,NULL),(122,'I believe influence comes from the mind','Atheism','US-SA-HASDF','Question',NULL,'/posts/1/I believe influence comes from the mind.txt','',NULL,NULL,24,NULL,'2016-02-28 04:52:07','2016-02-28 18:41:19',1,0,0,8,NULL,NULL,NULL),(123,'This is my answer','Adaptia','US-SW-ACE','Question',NULL,'/posts/2/This is my answer.txt','',NULL,NULL,24,NULL,'2016-02-28 18:19:33','2016-02-28 18:22:02',2,0,0,8,NULL,NULL,NULL),(124,'This is my answer to thequestion too','Buddhism','No-Beacon','Question',NULL,'/posts/8/This is my answer to thequestion too.txt','',NULL,NULL,24,NULL,'2016-02-28 18:22:45','2016-02-28 18:22:55',8,0,0,8,NULL,NULL,NULL),(125,'My test extension for you!','Ba Gua','US-CS-SFR','Post',NULL,'/extensions/8/My test extension for you!.txt','',49,NULL,NULL,NULL,'2016-02-28 18:29:56','2016-02-28 18:30:13',8,0,1,1,NULL,NULL,NULL),(126,'By a larger being','Ba Gua','US-CS-SFR','Extension',NULL,'/extensions/8/By a larger being.txt','',49,125,NULL,NULL,'2016-02-28 18:30:13','2016-02-28 18:30:13',8,0,0,8,NULL,NULL,NULL),(127,'My new extension of this','Atheism','US-SW-ACE','Post',NULL,'/extensions/2/My new extension of this.txt','',49,NULL,NULL,NULL,'2016-03-20 06:05:04','2016-03-20 06:05:04',2,0,0,1,NULL,NULL,NULL),(128,'This is where inspirations come from','Atheism','No-Beacon','Question',NULL,'/posts/14/This is where inspirations come from.txt','',NULL,NULL,24,NULL,'2016-03-21 06:38:03','2016-03-21 06:40:02',14,0,1,8,NULL,NULL,NULL),(129,'This is my extension232','Christianity','No-Beacon','Extension',NULL,'/posts/14/This is my extension232.txt','',NULL,128,24,NULL,'2016-03-21 06:40:02','2016-03-21 06:40:10',14,0,0,14,NULL,NULL,NULL),(130,'What a cool extension','Islam','No-Beacon','Post',NULL,'/extensions/14/What a cool extension.txt','',50,NULL,NULL,NULL,'2016-03-21 06:42:38','2016-03-21 06:42:38',14,0,0,14,NULL,NULL,NULL),(131,'my new extension of mailer','Atheism','US-IS-022','Post',NULL,'/posts/1/my new extension of mailer.txt','',52,NULL,NULL,NULL,'2016-03-23 05:28:30','2016-03-24 19:57:19',1,0,0,1,NULL,NULL,NULL),(132,'testas3','Christianity','Us-FD-FW','Post',NULL,'/extensions/1/testas3.txt','',51,NULL,NULL,NULL,'2016-03-24 20:01:29','2016-03-24 20:01:29',1,0,0,2,NULL,NULL,NULL),(133,'New extensions safas','Atheism','US-SW-IHOM2','Post',NULL,'/extensions/1/New extensions safas.txt','',53,NULL,NULL,NULL,'2016-03-25 05:25:47','2016-03-25 05:26:03',1,0,1,1,NULL,NULL,NULL),(134,'Extendcetpion','Buddhism','US-SA-HASDF','Extension',NULL,'/posts/1/Extendcetpion.txt','',53,133,NULL,NULL,'2016-03-25 05:26:03','2016-03-26 06:18:28',1,0,0,1,NULL,NULL,NULL),(135,'This is awesome!','Buddhism','US-SW-IHOM2','Post',NULL,'/extensions/2/This is awesome!.txt','',53,NULL,NULL,NULL,'2016-03-25 05:30:28','2016-03-25 05:30:28',2,0,0,1,NULL,NULL,NULL),(136,'Notha','Ba Gua','Us-FD-FW','Post',NULL,'/extensions/2/Notha.txt','',51,NULL,NULL,NULL,'2016-03-25 05:40:06','2016-03-25 05:40:06',2,0,0,2,NULL,NULL,NULL),(137,'What does it mean to love?','Adaptia','No-Beacon','Question',NULL,'/extensions/9/What does it mean to love?.txt','',NULL,NULL,24,NULL,'2016-03-25 06:16:39','2016-03-25 06:16:39',9,0,0,8,NULL,NULL,NULL),(138,'My question','Atheism','US-IS-022','Question',NULL,'/extensions/13/My question.txt','',NULL,NULL,24,NULL,'2016-03-25 06:17:46','2016-03-25 06:17:46',13,0,0,8,NULL,NULL,NULL),(139,'This thing?','Judaism','US-CS-SFR','Post',NULL,'/extensions/1/This thing?.txt','',53,NULL,NULL,NULL,'2016-03-26 07:44:02','2016-03-26 07:44:02',1,0,0,1,NULL,NULL,NULL),(140,'What a cool poster2','Buddhism','US-SW-ACE','Post',NULL,'/extensions/2/What a cool poster2.txt','',54,NULL,NULL,NULL,'2016-03-28 20:47:05','2016-03-28 20:47:05',2,0,0,2,NULL,NULL,NULL),(142,'Thisisi m ytester','Adaptia','US-SW-IHOM2','Post',NULL,'/extensions/1/Thisisi m ytester.txt','',56,NULL,NULL,NULL,'2016-04-02 23:27:32','2016-04-02 23:28:49',1,0,0,1,1,NULL,NULL),(143,'This is my extension title','Buddhism','US-SW-IHOM2','Post',NULL,'/extensions/17/This is my extension title.txt','',56,NULL,NULL,NULL,'2016-04-07 06:52:04','2016-04-07 07:37:01',20,0,0,1,NULL,NULL,NULL),(144,'My extension of this post','Ba Gua','US-CS-SFR','Post',NULL,'/extensions/1/My extension of this post.txt','',58,NULL,NULL,NULL,'2016-04-07 06:55:02','2016-04-11 07:58:31',20,1,1,17,NULL,NULL,NULL),(145,'My ability to love others','Adaptia','US-SA-HASDF','Question',NULL,'/extensions/1/My ability to love others.txt','',NULL,NULL,25,NULL,'2016-04-07 07:01:19','2016-04-07 07:38:04',20,0,0,17,NULL,NULL,NULL),(146,'We build together','Christianity','No-Beacon','Question',NULL,'/extensions/17/We build together.txt','',NULL,NULL,25,NULL,'2016-04-07 07:06:41','2016-04-07 07:38:04',20,0,0,17,NULL,NULL,NULL),(147,'New extension','Adaptia','No-Beacon','Post',NULL,'/extensions/22/New extension.txt','',52,NULL,NULL,NULL,'2016-04-07 20:13:43','2016-05-02 06:20:06',20,2,1,1,NULL,NULL,NULL),(148,'This is great!','Atheism','No-Beacon','Question',NULL,'/extensions/22/This is great!.txt','',NULL,NULL,25,NULL,'2016-04-07 20:15:22','2016-04-07 21:38:04',20,0,0,20,NULL,NULL,NULL),(149,'Love this post!','Adaptia','No-Beacon','Extension',NULL,'/extensions/23/Love this post!.txt','',52,147,NULL,NULL,'2016-04-07 22:23:42','2016-04-07 22:24:45',20,0,0,20,NULL,NULL,NULL),(150,'my new extension','Adaptia','No-Beacon','Post',NULL,'/extensions/24/my new extension.txt','',60,NULL,NULL,NULL,'2016-04-07 22:33:38','2016-04-15 04:57:00',20,1,0,20,NULL,NULL,NULL),(151,'this is cool','Atheism','No-Beacon','Post',NULL,'/extensions/25/this is cool.txt','',58,NULL,NULL,NULL,'2016-04-07 22:39:21','2016-04-11 05:46:38',20,2,0,20,NULL,NULL,NULL),(152,'What do you think?23','Ba Gua','US-CS-SFR','Extension',NULL,'/extensions/1/What do you think?23.txt','',58,144,NULL,NULL,'2016-04-11 07:58:31','2016-04-11 07:58:31',1,0,0,20,NULL,NULL,NULL),(153,'This is my extension','Adaptia','No-Beacon','Post',NULL,'/extensions/31/This is my extension.txt','',70,NULL,NULL,NULL,'2016-04-12 06:59:43','2016-04-12 06:59:43',31,0,0,31,NULL,NULL,NULL),(154,'Another extension','Adaptia','No-Beacon','Post',NULL,'/extensions/31/Another extension.txt','',68,NULL,NULL,NULL,'2016-04-12 07:00:03','2016-04-12 07:00:03',31,0,0,20,NULL,NULL,NULL),(155,'this is as ','Adaptia','US-SA-HASDF','Post',NULL,'/extensions/1/this is as .txt','',68,NULL,NULL,NULL,'2016-04-13 07:30:55','2016-04-13 07:30:55',1,0,0,20,NULL,NULL,NULL),(156,'another extesion23','Adaptia','US-SA-HASDF','Post',NULL,'/extensions/1/another extesion23.txt','',68,NULL,NULL,NULL,'2016-04-13 07:33:55','2016-04-13 07:33:55',1,0,0,20,NULL,NULL,NULL),(157,'my testser','Adaptia','US-SA-HASDF','Post',NULL,'/extensions/1/my testser.txt','',69,NULL,NULL,NULL,'2016-04-13 07:34:20','2016-04-13 07:34:20',1,0,0,1,NULL,NULL,NULL),(158,'my nextasdf','Adaptia','US-SF-Sdfw','Post',NULL,'/extensions/1/my nextasdf.txt','',71,NULL,NULL,NULL,'2016-04-18 07:25:38','2016-04-18 07:25:38',1,0,0,1,NULL,NULL,NULL),(159,'This si masdf','Atheism','No-Beacon','Post',NULL,'/extensions/33/This si masdf.txt','',71,NULL,NULL,NULL,'2016-04-18 07:30:14','2016-04-18 07:30:14',33,0,0,1,NULL,NULL,NULL),(160,'I don\'t agree with this','Ba Gua','No-Beacon','Question',NULL,'/extensions/33/I don\'t agree with this.txt','',NULL,NULL,25,NULL,'2016-04-18 07:30:48','2016-04-18 07:30:48',33,0,0,20,NULL,NULL,NULL),(161,'asdfasdfasdf','Atheism','US-SA-HASDF','Post',NULL,'/extensions/1/asdfasdfasdf.txt','',75,NULL,NULL,NULL,'2016-04-19 08:05:38','2016-04-21 22:08:39',1,0,1,1,NULL,NULL,NULL),(162,'My extension','Buddhism','US-SW-23','Extension',NULL,'/extensions/8/My extension.txt','',75,161,NULL,NULL,'2016-04-21 22:08:39','2016-04-27 00:10:15',8,1,0,1,NULL,NULL,NULL),(163,'My second gps','Adaptia','US-SW-23','Post',NULL,'/extensions/1/My second gps.txt','',79,NULL,NULL,NULL,'2016-04-27 00:29:25','2016-04-27 00:29:25',1,0,0,1,NULL,48.505077,-122.230191),(164,'my new extension','Buddhism','TK-Sesdr','Post',NULL,'/extensions/2/my new extension.txt','',79,NULL,NULL,NULL,'2016-04-27 00:34:44','2016-04-27 00:34:44',2,0,0,1,NULL,43.773175,11.255949),(165,'My new extenson woohoo','Atheism','TK-Sesdr','Post',NULL,'/extensions/9/My new extenson woohoo.txt','',79,NULL,NULL,NULL,'2016-04-27 01:58:19','2016-04-27 01:58:19',9,0,0,1,NULL,43.773175,11.255949),(166,'newwer','Atheism','US-SW-23','Post',NULL,'/extensions/29/newwer.txt','',78,NULL,NULL,NULL,'2016-04-27 02:00:11','2016-04-27 02:00:11',29,0,0,8,NULL,48.505077,-122.230191),(167,'this is','Atheism','TK-Sesdr','Post',NULL,'/extensions/29/this is.txt','',80,NULL,NULL,NULL,'2016-04-27 02:01:44','2016-04-27 02:01:44',29,0,0,29,NULL,43.773175,11.255949),(168,'this is my test','Atheism','No-Beacon','Post',NULL,'/extensions/33/this is my test.txt','',81,NULL,NULL,NULL,'2016-04-27 06:35:31','2016-04-29 20:28:00',33,1,1,33,NULL,NULL,NULL),(169,'Not so much ba','Atheism','US-SW-IHOM2','Post',NULL,'/extensions/33/Not so much ba.txt','',82,NULL,NULL,NULL,'2016-04-28 07:21:08','2016-04-28 07:24:02',33,0,1,1,NULL,NULL,NULL),(170,'whatcha know','Christianity','US-SW-IHOM2','Extension',NULL,'/extensions/33/whatcha know.txt','',82,169,NULL,NULL,'2016-04-28 07:24:02','2016-04-28 07:24:02',33,0,0,33,NULL,NULL,NULL),(171,'his place extension','Atheism','No-Beacon','Extension',NULL,'/extensions/1/his place extension.txt','',81,168,NULL,NULL,'2016-04-29 20:28:00','2016-05-11 22:40:02',1,0,0,33,NULL,NULL,NULL),(172,'My extension of you','Druze','No-Beacon','Post',NULL,'/extensions/1/My extension of you.txt','',85,NULL,NULL,NULL,'2016-04-29 22:06:20','2016-05-11 22:40:02',1,0,0,33,NULL,NULL,NULL),(173,'I\'m in Duomo too','Druze','IT-FLR-Duomo','Post',NULL,'/extensions/33/I\'m in Duomo too.txt','',86,NULL,NULL,NULL,'2016-04-30 06:49:59','2016-05-02 07:48:50',33,1,0,1,NULL,43.773175,11.255949),(174,'new extension','Christianity','No-Beacon','Post',NULL,'/extensions/1/new extension.txt','',86,NULL,NULL,NULL,'2016-05-01 00:42:08','2016-05-11 22:40:02',1,0,0,1,NULL,NULL,NULL),(175,'My answer to you','Adaptia','US-SA-HASDF','Question',NULL,'/extensions/1/My answer to you.txt','',NULL,NULL,26,NULL,'2016-05-01 01:05:24','2016-05-01 01:05:24',1,0,0,2,NULL,NULL,NULL),(176,'Nice extension','Adaptia','IT-FLR-Duomo','Post',NULL,'/extensions/1/Nice extension.txt','',85,NULL,NULL,NULL,'2016-05-01 01:13:02','2016-05-02 07:48:17',1,0,1,33,NULL,43.773175,11.255949),(177,'asdfasdf234','Adaptia','US-SW-IHOM2','Post',NULL,'/extensions/1/asdfasdf234.txt','',87,NULL,NULL,NULL,'2016-05-01 01:19:11','2016-05-01 01:19:11',1,0,0,1,NULL,0.000000,0.000000),(178,'My extends','Adaptia','IT-FLR-Duomo','Post',NULL,'/extensions/1/My extends.txt','',88,NULL,NULL,NULL,'2016-05-01 03:30:21','2016-05-01 03:30:21',1,0,0,15,NULL,43.773175,11.255949),(179,'new extension23','Adaptia','US-SA-HASDF','Post',NULL,'/extensions/1/new extension23.txt','',88,NULL,NULL,NULL,'2016-05-02 06:20:36','2016-05-02 06:20:36',1,0,0,15,NULL,NULL,NULL),(180,'asdfasdf2323','Atheism','No-Beacon','Extension',NULL,'/posts/1/asdfasdf2323.txt','',85,176,NULL,NULL,'2016-05-02 07:48:17','2016-05-12 02:10:28',1,0,1,1,NULL,NULL,NULL),(181,'My duomo extension','Christianity','IT-FLR-Duomo','Extension',NULL,'/extensions/2/My duomo extension.txt','',85,180,NULL,NULL,'2016-05-03 05:52:02','2016-05-03 05:52:02',2,0,0,1,NULL,43.773175,11.255949),(182,'My first','Adaptia','US-SA-HASDF','Post',NULL,'/extensions/1/My first.txt','',91,NULL,NULL,NULL,'2016-05-09 06:45:02','2016-05-09 06:45:02',1,0,0,1,NULL,NULL,NULL),(183,'This is my title','Adaptia','No-Beacon','Post',NULL,'/posts/33/This is my title.txt','',92,NULL,NULL,NULL,'2016-05-11 21:38:02','2016-05-12 02:10:28',33,0,0,1,NULL,NULL,NULL),(184,'new extension for you!','Christianity','No-Beacon','Post',NULL,'/extensions/33/new extension for you!.txt','',92,NULL,NULL,NULL,'2016-05-11 22:21:38','2016-05-11 22:30:00',33,0,1,1,NULL,NULL,NULL),(185,'asdfasdf23423','Druze','No-Beacon','Extension',NULL,'/posts/1/asdfasdf23423.txt','',92,184,NULL,NULL,'2016-05-11 22:30:00','2016-05-12 02:10:28',1,0,1,33,NULL,NULL,NULL),(186,'asdfasdf23','Druze','No-Beacon','Extension',NULL,'/extensions/33/asdfasdf23.txt','',92,185,NULL,NULL,'2016-05-11 22:30:50','2016-05-11 22:35:25',33,0,0,1,NULL,NULL,NULL),(187,'test 5.2','Islam','US-SF-Sdfw','Post',NULL,'/extensions/1/test 5.2.txt','',94,NULL,NULL,NULL,'2016-05-13 18:11:28','2016-05-13 18:11:28',1,0,0,1,NULL,0.000000,0.000000),(188,'My first extension bro2','Islam','US-SA-HASDF','Post',NULL,'/extensions/1/My first extension bro2.txt','',95,NULL,NULL,NULL,'2016-05-15 21:48:02','2016-05-15 21:48:02',1,0,0,35,NULL,NULL,NULL),(189,'Yes we can','Christianity','US-SW-ACE','Question',NULL,'/posts/1/Yes we can.txt','',NULL,NULL,30,NULL,'2016-05-16 07:50:00','2016-05-16 20:10:10',1,0,1,1,NULL,NULL,NULL),(190,'another extension23','Adaptia','US-SA-HASDF','Extension',NULL,'/extensions/1/another extension23.txt','',NULL,189,30,NULL,'2016-05-16 07:50:33','2016-05-16 07:50:33',1,0,0,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `extensions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `intolerances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `intolerances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_ruling` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `extension_id` int(10) unsigned DEFAULT NULL,
  `question_id` int(10) unsigned DEFAULT NULL,
  `legacy_post_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `beacon_tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `intolerances_user_id_foreign` (`user_id`),
  CONSTRAINT `intolerances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `intolerances` WRITE;
/*!40000 ALTER TABLE `intolerances` DISABLE KEYS */;
INSERT INTO `intolerances` VALUES (10,'this is intolerance because',27,NULL,NULL,NULL,1,'2016-01-23 00:23:33','2016-01-23 00:23:33',''),(11,'I think this is intolerance with so much more',NULL,NULL,NULL,27,2,'2016-01-23 00:28:46','2016-01-25 06:00:47',''),(12,'This is my intolerance message',27,NULL,NULL,NULL,2,'2016-01-23 00:38:38','2016-01-23 00:38:38',''),(13,'This is total bs c\'mon',25,NULL,NULL,NULL,2,'2016-01-23 00:46:16','2016-01-23 00:46:16',''),(14,'This is a longer intolelrance what do you think it looks like with all this text?  Can it be a big problem?  or just a short text?  I hope you can be a good man with this suggestions.  Do you think it is a good idea?  Or maybe just be a happy person or else to be one with the earth and then some ',NULL,NULL,NULL,27,1,'2016-01-25 05:49:36','2016-01-25 05:49:36',''),(15,'This is an intolerant belief because it sucks and doesn\'t source any of the citations.',NULL,NULL,NULL,28,5,'2016-01-25 09:19:54','2016-01-25 09:20:04',''),(18,'This is intolerance because of a lame source and no bulk.  Need sources!',NULL,NULL,NULL,31,1,'2016-01-27 07:57:33','2016-01-27 07:57:33',''),(19,'This is totla bs',8,NULL,NULL,NULL,1,'2016-01-27 08:35:13','2016-01-27 08:35:13',''),(21,'This is bs!',69,NULL,NULL,NULL,6,'2016-01-30 00:28:42','2016-01-30 00:28:42',''),(22,'This is so intolerant',NULL,NULL,NULL,55,20,'2016-04-07 07:22:28','2016-04-07 07:37:01',''),(24,'this is so intolerant!',154,NULL,NULL,NULL,1,'2016-04-15 18:26:08','2016-04-15 18:26:08',''),(25,'This is intolerant because its is bad.',NULL,NULL,NULL,78,1,'2016-05-05 05:27:45','2016-05-05 05:46:13','US-SW-23'),(26,'This is so intolerant',NULL,NULL,NULL,85,1,'2016-05-05 05:47:04','2016-05-11 22:40:02','No-Beacon'),(27,'I find this post so intolerantasdf',NULL,NULL,NULL,92,33,'2016-05-11 21:38:43','2016-05-11 22:22:07','No-Beacon'),(28,'This isp asdf',NULL,NULL,NULL,93,1,'2016-05-11 22:24:16','2016-05-11 22:24:46','No-Beacon'),(29,'so bad',185,NULL,NULL,NULL,33,'2016-05-11 22:33:01','2016-05-11 22:35:25','No-Beacon');
/*!40000 ALTER TABLE `intolerances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invites_to_email_unique` (`email`),
  KEY `invites_user_id_foreign` (`user_id`),
  CONSTRAINT `invites_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invites` WRITE;
/*!40000 ALTER TABLE `invites` DISABLE KEYS */;
INSERT INTO `invites` VALUES (1,'nadnerb001@gmail.com','2016-04-06 21:20:52','2016-04-06 21:20:52',19),(2,'my@f.com','2016-04-18 07:35:13','2016-04-18 07:35:13',33);
/*!40000 ALTER TABLE `invites` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_reserved_at_index` (`queue`,`reserved`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `legacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legacy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `elevation` int(10) unsigned NOT NULL,
  `extension` int(10) unsigned NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `legacy` WRITE;
/*!40000 ALTER TABLE `legacy` DISABLE KEYS */;
/*!40000 ALTER TABLE `legacy` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `legacy_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legacy_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8_unicode_ci,
  `elevation` int(10) unsigned NOT NULL,
  `extension` int(10) unsigned NOT NULL,
  `post_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `legacy_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `legacy_posts_legacy_id_foreign` (`legacy_id`),
  CONSTRAINT `legacy_posts_legacy_id_foreign` FOREIGN KEY (`legacy_id`) REFERENCES `legacy` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `legacy_posts` WRITE;
/*!40000 ALTER TABLE `legacy_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `legacy_posts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2015_10_15_232043_create_users_table',1),('2015_10_15_232413_create_password_resets_table',1),('2015_10_15_232517_create_sponsors_table',1),('2015_10_15_232822_create_sponsorships_table',1),('2015_10_15_233102_create_sponsor_promo_table',1),('2015_10_15_233351_create_posts_table',1),('2015_10_15_233512_create_drafts_table',1),('2015_10_15_233624_create_extensions_table',1),('2015_10_15_233759_create_versions_table',1),('2015_10_15_233914_create_questions_table',1),('2015_10_15_234038_create_elevation_table',1),('2015_10_15_234219_create_intolerant_table',1),('2015_10_15_234409_create_nymified_table',1),('2015_10_15_234459_create_beacons_table',1),('2015_10_15_234539_create_invites_table',1),('2015_10_20_081730_create_jobs_table',1),('2015_10_25_033612_create_legacy_table',1),('2015_10_25_033653_create_legacy_posts_table',1),('2015_10_28_211547_create_sources_table',1),('2015_10_29_214355_create_artists_table',1),('2015_11_03_072143_create_songs_table',1),('2015_12_04_004047_update_column_names',1),('2015_12_04_084958_update_column_cleanup',1),('2015_12_05_005041_update_invites_email',1),('2015_12_10_235143_update_extensions_elevate',1),('2015_12_13_000038_add_source_user_elevation_extension',1),('2015_12_19_193632_update_extension_names',1),('2015_12_20_082533_add_beacon_address',2),('2015_12_22_050119_update_beacon_tag_creations',3),('2015_12_22_233205_create_bookmarks_table',4),('2015_12_24_075241_update_user_type',4),('2016_01_09_071818_add_sponsor_email',5),('2016_01_19_054440_create_failed_jobs_table',6),('2016_01_20_004027_update_index_to_beliefs_categories',7),('2016_01_21_002418_remove_question_token',8),('2016_01_21_234919_recreate_intolerances_table',9),('2016_01_21_235017_create_moderations_table',9),('2016_01_21_235902_add_status_to_posts_extensions',9),('2016_01_23_005120_update_intolerances_mod_columns',10),('2016_01_24_233813_add_userid_foreign_relationship',11),('2016_01_25_105048_create_adjudications_table',12),('2016_01_27_232800_create_supports_table',13),('2016_02_14_035602_create_notifications_table',14),('2016_02_16_010340_update_bookmarks_title',15),('2016_02_17_052114_change_category_to_source',16),('2016_02_21_010954_add_cashier_columns',17),('2016_02_23_022056_add_beacon_photo_guide',18),('2016_02_26_054044_add_sponsor_stripe',19),('2016_03_21_065840_drop_unique_beta_code',20),('2016_03_22_062941_create_beacon_requests_table',21),('2016_03_23_035743_update_beacon_phone_manager',22),('2016_03_23_183352_create_sponsor_requests_table',23),('2016_03_23_184604_update_sponsor_address_location',23),('2016_03_25_041647_add_sponsor_click_columns',24),('2016_03_31_165540_beacon_sponsor_admin_updates',25),('2016_03_31_191448_remove_unique_emails',26),('2016_03_31_215655_add_email_sponsor_beacon_requests',26),('2016_04_13_045513_user_email_rules',27),('2016_04_21_185916_add_beacon_long_lat',28),('2016_04_21_214555_add_gps_to_posts_extensions',28),('2016_04_21_230428_update_user_local_global',28),('2016_04_26_184830_add_lat_long_for_sponsors',28),('2016_04_29_170933_change_location_to_city_remove_codes',29),('2016_04_29_212804_rename_elevation_to_elevations',30),('2016_04_29_212930_add_beacon_tag_to_elevations',30),('2016_05_05_051017_add_beacon_tag_to_intolerance',31),('2016_05_09_020519_drop_beacon_tier_add_zip',32),('2016_05_09_021616_add_sponsor_zip',32),('2016_05_11_023606_add_zendesk_id_supports',33),('2016_05_11_175458_add_beacon_tag_views',34);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `moderations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moderations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mod_ruling` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `intolerance_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `moderations_intolerance_id_foreign` (`intolerance_id`),
  KEY `moderations_user_id_foreign` (`user_id`),
  CONSTRAINT `moderations_intolerance_id_foreign` FOREIGN KEY (`intolerance_id`) REFERENCES `intolerances` (`id`),
  CONSTRAINT `moderations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `moderations` WRITE;
/*!40000 ALTER TABLE `moderations` DISABLE KEYS */;
INSERT INTO `moderations` VALUES (7,'Yes this is indeed intolerance because of the above mentioned reason.  Furthermore if the user would change the hate words to non-swear words this would no longer be intolerance.s',14,'2016-01-25 05:55:52','2016-01-25 06:28:46',2),(8,'If the user sorts the sources and cites them then there would be no intolerance. And I think it is a terrible idea.  Yet another bad citation by z.',15,'2016-01-25 09:22:46','2016-01-25 10:34:13',2),(10,'Yes this is intolerant because it doesn\'t contain sources.  We recommend a lock until sources are added.',18,'2016-01-27 07:59:08','2016-01-27 07:59:08',2),(11,'Yes this is intolerance',19,'2016-01-27 08:35:52','2016-01-27 08:35:52',2),(12,'Yes this is intolernace',15,'2016-01-28 01:34:24','2016-01-28 01:34:24',1),(16,'This is the correct form of moderation',21,'2016-04-02 22:46:18','2016-04-02 22:46:18',1),(17,'Yes this is intolerant',22,'2016-04-07 07:26:48','2016-04-07 07:26:48',1);
/*!40000 ALTER TABLE `moderations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `source_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `source_user` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (4,'Elevated','Post',32,'tester',5,1,'2016-02-14 07:11:26','2016-02-14 07:11:26'),(25,'Extended','Extension',101,'This is my extension',6,6,'2016-02-17 07:09:46','2016-02-17 07:09:46'),(26,'Extended','Extension',102,'my next extesnion',6,6,'2016-02-17 07:10:08','2016-02-17 07:10:08'),(27,'Extended','Extension',103,'another extensionas',6,6,'2016-02-17 07:10:22','2016-02-17 07:10:22'),(28,'Extended','Extension',105,'asasdasdf',6,6,'2016-02-17 07:11:06','2016-02-17 07:11:06'),(29,'Extended','Extension',107,'asdfasdfasdf',5,5,'2016-02-18 08:11:24','2016-02-18 08:11:24'),(33,'Extended','Extension',110,'asdfasdfasd',5,2,'2016-02-19 10:25:06','2016-02-19 10:25:06'),(34,'Extended','Extension',111,'My 2as',8,8,'2016-02-23 06:50:45','2016-02-23 06:50:45'),(43,'Extended','Extension',116,'23rasdf',8,8,'2016-02-25 06:21:38','2016-02-25 06:21:38'),(44,'Extended','Extension',117,'this is cool',8,1,'2016-02-25 06:22:12','2016-02-25 06:22:12'),(47,'Elevated','Extension',115,'My first extension',8,1,'2016-02-25 20:09:02','2016-02-25 20:09:02'),(48,'Elevated','Extension',116,'23rasdf',8,1,'2016-02-25 20:09:07','2016-02-25 20:09:07'),(55,'Elevated','Extension',116,'23rasdf',8,6,'2016-02-25 21:16:43','2016-02-25 21:16:43'),(56,'Elevated','Extension',115,'My first extension',8,6,'2016-02-25 21:16:53','2016-02-25 21:16:53'),(58,'Elevated','Question',20,'Final question before Vivian talk?',8,1,'2016-02-28 04:38:52','2016-02-28 04:38:52'),(59,'Elevated','Question',21,'Must be getting to the last question?',8,1,'2016-02-28 04:42:13','2016-02-28 04:42:13'),(60,'Elevated','Question',24,'Where does influence come from?',8,1,'2016-02-28 04:51:35','2016-02-28 04:51:35'),(61,'Elevated','Question',24,'Where does influence come from?',8,2,'2016-02-28 18:18:58','2016-02-28 18:18:58'),(63,'Extended','Extension',126,'By a larger being',8,8,'2016-02-28 18:30:13','2016-02-28 18:30:13'),(65,'Extended','Extension',129,'This is my extension232',14,14,'2016-03-21 06:40:02','2016-03-21 06:40:02'),(66,'Extended','Extension',130,'What a cool extension',14,14,'2016-03-21 06:42:38','2016-03-21 06:42:38'),(79,'Elevated','Post',50,'My first post here:',14,1,'2016-03-30 09:34:27','2016-03-30 09:34:27'),(82,'Extended','Extension',144,'My extension of this post',17,1,'2016-04-07 06:55:02','2016-04-07 06:55:02'),(83,'Elevated','Post',58,'This post is enough',17,1,'2016-04-07 07:01:37','2016-04-07 07:01:37'),(93,'Elevated','Post',60,'My new post',20,1,'2016-04-11 00:18:06','2016-04-11 00:18:06'),(94,'Elevated','Extension',151,'this is cool',20,8,'2016-04-11 05:21:05','2016-04-11 05:21:05'),(95,'Elevated','Extension',151,'this is cool',20,1,'2016-04-11 05:46:38','2016-04-11 05:46:38'),(96,'Elevated','Extension',144,'My extension of this post',20,1,'2016-04-11 07:58:19','2016-04-11 07:58:19'),(97,'Extended','Extension',152,'What do you think?23',20,1,'2016-04-11 07:58:31','2016-04-11 07:58:31'),(98,'Extended','Extension',153,'This is my extension',31,31,'2016-04-12 06:59:43','2016-04-12 06:59:43'),(99,'Elevated','Post',68,'This is my longer posthis ',20,31,'2016-04-12 06:59:50','2016-04-12 06:59:50'),(100,'Extended','Extension',154,'Another extension',20,31,'2016-04-12 07:00:03','2016-04-12 07:00:03'),(101,'Extended','Extension',155,'this is as ',20,1,'2016-04-13 07:30:55','2016-04-13 07:30:55'),(102,'Extended','Extension',156,'another extesion23',20,1,'2016-04-13 07:33:55','2016-04-13 07:33:55'),(104,'Elevated','Post',70,'My first post yupppie!',31,1,'2016-04-15 04:46:02','2016-04-15 04:46:02'),(105,'Elevated','Extension',150,'my new extension',20,1,'2016-04-15 04:57:00','2016-04-15 04:57:00'),(106,'Elevated','Question',25,'How do we become perfect lovers?',20,1,'2016-04-18 05:37:26','2016-04-18 05:37:26'),(110,'Elevated','Question',25,'How do we become perfect lovers?',20,33,'2016-04-18 07:30:35','2016-04-18 07:30:35'),(113,'Elevated','Extension',162,'My extension',8,1,'2016-04-27 00:10:15','2016-04-27 00:10:15'),(117,'Extended','Extension',166,'newwer',8,29,'2016-04-27 02:00:11','2016-04-27 02:00:11'),(118,'Extended','Extension',167,'this is',29,29,'2016-04-27 02:01:44','2016-04-27 02:01:44'),(119,'Extended','Extension',168,'this is my test',33,33,'2016-04-27 06:35:31','2016-04-27 06:35:31'),(120,'Elevated','Extension',168,'this is my test',33,1,'2016-04-28 07:13:29','2016-04-28 07:13:29'),(122,'Extended','Extension',170,'whatcha know',33,33,'2016-04-28 07:24:02','2016-04-28 07:24:02'),(124,'Elevated','Post',80,'My first',29,33,'2016-04-28 07:25:16','2016-04-28 07:25:16'),(125,'Extended','Extension',171,'his place extension',33,1,'2016-04-29 20:28:00','2016-04-29 20:28:00'),(127,'Elevated','Post',85,'Newwe',33,1,'2016-04-29 22:06:03','2016-04-29 22:06:03'),(128,'Extended','Extension',172,'My extension of you',33,1,'2016-04-29 22:06:20','2016-04-29 22:06:20'),(133,'Extended','Extension',176,'Nice extension',33,1,'2016-05-01 01:13:02','2016-05-01 01:13:02'),(135,'Extended','Extension',178,'My extends',15,1,'2016-05-01 03:30:21','2016-05-01 03:30:21'),(136,'Elevated','Post',68,'This is my longer posthis ',20,1,'2016-05-02 05:22:07','2016-05-02 05:22:07'),(137,'Elevated','Post',81,'this is my post title',33,1,'2016-05-02 05:54:21','2016-05-02 05:54:21'),(138,'Elevated','Post',58,'This post is enough',20,1,'2016-05-02 06:01:42','2016-05-02 06:01:42'),(139,'Elevated','Post',88,'new may post',15,1,'2016-05-02 06:16:23','2016-05-02 06:16:23'),(140,'Elevated','Extension',147,'New extension',20,1,'2016-05-02 06:20:06','2016-05-02 06:20:06'),(141,'Extended','Extension',179,'new extension23',15,1,'2016-05-02 06:20:36','2016-05-02 06:20:36'),(143,'Elevated','Extension',173,'I\'m in Duomo too',33,1,'2016-05-02 07:48:50','2016-05-02 07:48:50'),(145,'Extended','Extension',182,'My first',1,1,'2016-05-09 06:45:02','2016-05-09 06:45:02'),(146,'Elevated','Post',90,'My new post',2,1,'2016-05-09 06:45:12','2016-05-09 06:45:12'),(147,'Extended','Extension',183,'This is my title',1,33,'2016-05-11 21:38:02','2016-05-11 21:38:02'),(148,'Elevated','Post',92,'My first post',1,33,'2016-05-11 21:38:23','2016-05-11 21:38:23'),(149,'Extended','Extension',184,'new extension for you!',1,33,'2016-05-11 22:21:38','2016-05-11 22:21:38'),(150,'Extended','Extension',185,'asdfasdf23423',33,1,'2016-05-11 22:30:00','2016-05-11 22:30:00'),(151,'Extended','Extension',186,'asdfasdf23',1,33,'2016-05-11 22:30:50','2016-05-11 22:30:50'),(152,'Extended','Extension',187,'test 5.2',1,1,'2016-05-13 18:11:28','2016-05-13 18:11:28'),(153,'Elevated','Post',95,'Hey my first post here!',35,1,'2016-05-15 21:46:56','2016-05-15 21:46:56'),(154,'Extended','Extension',188,'My first extension bro2',35,1,'2016-05-15 21:48:02','2016-05-15 21:48:02'),(155,'Elevated','Question',30,'Can we love someone of a different belief?',1,1,'2016-05-16 07:50:06','2016-05-16 07:50:06'),(156,'Extended','Extension',190,'another extension23',1,1,'2016-05-16 07:50:33','2016-05-16 07:50:33');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `nymified`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nymified` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `n_post_id` int(10) unsigned DEFAULT NULL,
  `n_extension_id` int(10) unsigned DEFAULT NULL,
  `n_question_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nymified_user_id_foreign` (`user_id`),
  CONSTRAINT `nymified_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `nymified` WRITE;
/*!40000 ALTER TABLE `nymified` DISABLE KEYS */;
/*!40000 ALTER TABLE `nymified` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8_unicode_ci,
  `elevation` int(10) unsigned NOT NULL,
  `extension` int(10) unsigned NOT NULL,
  `master_version_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nymified` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `belief` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `beacon_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  `status` tinyint(3) unsigned DEFAULT NULL,
  `lat` double(10,6) DEFAULT NULL,
  `long` double(10,6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_user_id_foreign` (`user_id`),
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,'first zoko garden',NULL,2,3,NULL,NULL,'Adaptia','No Beacon','Question','/posts/2/first zoko garden.txt',NULL,'2015-12-20 08:19:48','2016-01-27 09:39:44',2,NULL,NULL,NULL),(2,'My first garden amaricus',NULL,0,0,NULL,NULL,'Adaptia','No Beacon','Opinion','/posts/1/My first garden amaricus.txt',NULL,'2015-12-21 02:13:20','2015-12-21 02:13:20',1,NULL,NULL,NULL),(3,'Quick test of posint',NULL,1,0,NULL,NULL,'Adaptia','No Beacon','Opinion','/posts/1/Quick test of posint.txt',NULL,'2015-12-21 02:17:07','2015-12-21 02:17:34',1,NULL,NULL,NULL),(4,'big poster',NULL,1,0,NULL,NULL,'Adaptia','No Beacon','Opinion','/posts/2/big poster.txt',NULL,'2015-12-21 02:17:30','2015-12-21 07:21:02',2,NULL,NULL,NULL),(5,'test of a longer psot like wayy too l',NULL,0,3,NULL,NULL,'Adaptia','No Beacon','Prayer','/posts/1/test of a longer psot like wayy too l.txt',NULL,'2015-12-22 03:11:47','2015-12-27 09:27:51',1,NULL,NULL,NULL),(6,'Testing of posting today yippie2',NULL,0,0,NULL,NULL,'Atheism','US-SW-IHOM','Prayer','/posts/1/Testing of posting today yippie2.txt',NULL,'2015-12-22 05:11:57','2015-12-22 05:24:49',1,NULL,NULL,NULL),(7,'tester',NULL,0,0,NULL,NULL,'Ba Gua','No-Beacon','Prayer','/posts/1/tester.txt',NULL,'2015-12-22 05:18:36','2016-05-18 23:29:25',1,NULL,NULL,NULL),(8,'Testerup',NULL,1,0,NULL,NULL,'Buddhism','US-SW-ACE','Poem','/posts/1/Testerup.txt',NULL,'2015-12-22 05:26:38','2016-01-02 08:22:17',1,NULL,NULL,NULL),(9,'test of new posting',NULL,0,0,NULL,NULL,'Adaptia','No-Beacon','Poem','/posts/1/test of new posting.txt',NULL,'2015-12-25 17:04:03','2016-05-18 23:36:51',1,NULL,NULL,NULL),(10,'New poster today!',NULL,2,2,NULL,NULL,'Ba Gua','No-Beacon','Poem','/posts/1/New poster today!.txt',NULL,'2015-12-27 09:29:35','2016-05-18 23:36:51',1,NULL,NULL,NULL),(11,'woohoo my first post is here!',NULL,1,2,NULL,NULL,'Ba Gua','US-CS-SFW','Prayer','/posts/5/woohoo my first post is here!.txt',NULL,'2015-12-28 17:17:54','2016-01-11 04:47:20',5,NULL,NULL,NULL),(12,'big zoko post yay',NULL,1,1,NULL,NULL,'Ba Gua','No-Beacon','Verse','/posts/2/big zoko post yay.txt',NULL,'2015-12-28 21:00:43','2016-01-11 07:50:04',2,NULL,NULL,NULL),(13,'My post per today',NULL,2,3,NULL,NULL,'Ba Gua','No-Beacon','Prayer','/posts/1/My post per today.txt',NULL,'2015-12-28 23:36:18','2016-05-18 23:29:25',1,NULL,NULL,NULL),(14,'this is my post for today',NULL,1,1,NULL,NULL,'Adaptia','No-Beacon','Poem','/posts/1/this is my post for today.txt',NULL,'2015-12-31 08:20:06','2016-05-18 23:29:25',1,NULL,NULL,NULL),(15,'this is a test',NULL,0,0,NULL,NULL,'Atheism','No-Beacon','Poem','/posts/1/this is a test.txt',NULL,'2016-01-03 06:16:17','2016-05-18 23:29:25',1,NULL,NULL,NULL),(16,'testing',NULL,1,1,NULL,NULL,'Native','US-CS-SFW','Poem','/posts/2/testing.txt',NULL,'2016-01-06 08:15:10','2016-01-14 02:46:48',2,NULL,NULL,NULL),(17,'my christian post',NULL,0,0,NULL,NULL,'Christianity','US-SW-7DA','Prayer','/posts/1/my christian post.txt',NULL,'2016-01-07 11:00:00','2016-01-07 11:00:00',1,NULL,NULL,NULL),(18,'test post',NULL,1,1,NULL,NULL,'Christianity','No-Beacon','Prayer','/posts/1/test post.txt',NULL,'2016-01-11 07:04:18','2016-05-18 23:36:51',1,NULL,NULL,NULL),(19,'tester23',NULL,1,0,NULL,NULL,'Adaptia','No-Beacon','Scholar','/posts/1/tester23.txt',NULL,'2016-01-14 02:46:27','2016-05-18 23:36:51',1,NULL,NULL,NULL),(20,'Another post for you',NULL,1,0,NULL,NULL,'Druze','US-CS-SFW','Reflection','/posts/5/Another post for you.txt',NULL,'2016-01-15 08:11:04','2016-01-15 22:49:28',5,NULL,NULL,NULL),(21,'tester ',NULL,0,1,NULL,NULL,'Taoism','US-CS-SFW','Prayer','/posts/2/tester .txt',NULL,'2016-01-15 22:48:54','2016-01-15 22:49:12',2,NULL,NULL,NULL),(22,'Test post',NULL,0,0,NULL,NULL,'Indigenous','US-SW-IHOM2','Opinion','/posts/2/Test post.txt',NULL,'2016-01-18 23:21:51','2016-01-19 01:03:08',2,NULL,NULL,NULL),(23,'This is a title',NULL,0,1,NULL,NULL,'Buddhism','US-CS-SFW','Poem','/posts/2/This is a title.txt',NULL,'2016-01-19 01:18:49','2016-01-20 03:19:16',2,NULL,NULL,NULL),(24,'another draft',NULL,0,1,NULL,NULL,'Ba Gua','US-CS-SFW','Story','/posts/2/another draft.txt',NULL,'2016-01-20 04:01:33','2016-01-27 19:30:05',2,NULL,NULL,NULL),(26,'my fisrt poster',NULL,0,4,NULL,NULL,'Buddhism','US-SW-ACE','Opinion','/posts/1/my fisrt poster.txt',NULL,'2016-01-20 05:36:24','2016-01-20 06:40:24',1,NULL,NULL,NULL),(27,'My first big post',NULL,1,4,NULL,NULL,'Ba Gua','No-Beacon','Poem','/posts/6/My first big post.txt',NULL,'2016-01-20 06:42:48','2016-01-22 17:22:00',6,NULL,NULL,NULL),(28,'Tester2',NULL,0,4,NULL,NULL,'Indigenous','No-Beacon','Opinion','/posts/6/Tester2.txt',NULL,'2016-01-25 09:17:28','2016-01-28 01:34:37',6,1,NULL,NULL),(29,'test post23',NULL,0,4,NULL,NULL,'Ba Gua','No-Beacon','Poem','/posts/1/test post23.txt',NULL,'2016-01-25 12:08:34','2016-05-18 23:36:51',1,NULL,NULL,NULL),(30,'my poster232',NULL,2,1,NULL,NULL,'Ba Gua','US-CS-SFW','Poem','/posts/2/my poster232.txt',NULL,'2016-01-27 00:58:16','2016-02-14 06:38:14',2,NULL,NULL,NULL),(31,'test posters',NULL,0,1,NULL,NULL,'Hinduism','No-Beacon','Opinion','/posts/6/test posters.txt',NULL,'2016-01-27 07:35:43','2016-01-27 08:18:28',6,1,NULL,NULL),(32,'tester',NULL,1,1,NULL,NULL,'Ba Gua','US-CS-SFW','Poem','/posts/5/tester.txt',NULL,'2016-01-27 09:39:29','2016-02-14 07:11:26',5,NULL,NULL,NULL),(33,'this si my post',NULL,2,3,NULL,NULL,'Druze','US-CS-SFW','Reflection','/posts/2/this si my post.txt',NULL,'2016-01-28 02:51:24','2016-02-17 07:08:12',2,NULL,NULL,NULL),(34,'tes post here',NULL,0,2,NULL,NULL,'Ba Gua','No-Beacon','Poem','/posts/1/tes post here.txt',NULL,'2016-01-29 01:17:36','2016-05-18 23:36:51',1,NULL,NULL,NULL),(35,'tester roo',NULL,1,1,NULL,NULL,'Buddhism','No-Beacon','Reflection','/posts/6/tester roo.txt',NULL,'2016-01-30 00:27:46','2016-02-17 07:08:28',6,NULL,NULL,NULL),(36,'my test post23',NULL,1,0,NULL,NULL,'Ba Gua','US-SW-ACE','Reflection','/posts/1/my test post23.txt',NULL,'2016-02-12 04:23:11','2016-02-25 20:58:15',1,NULL,NULL,NULL),(37,'my big postersas',NULL,0,2,NULL,NULL,'Atheism','No-Beacon','Scripture','/posts/6/my big postersas.txt',NULL,'2016-02-13 02:46:34','2016-02-14 07:11:04',6,NULL,NULL,NULL),(38,'asdfasdf',NULL,0,2,NULL,NULL,'Buddhism','No-Beacon','Opinion','/posts/1/asdfasdf.txt',NULL,'2016-02-13 09:12:23','2016-05-18 23:29:25',1,NULL,NULL,NULL),(39,'asdfasdfasdf',NULL,0,1,NULL,NULL,'Christianity','No-Beacon','Reflection','/posts/1/asdfasdfasdf.txt',NULL,'2016-02-15 09:32:18','2016-02-19 05:29:34',1,NULL,NULL,NULL),(40,'This is also my question extension270',NULL,2,5,NULL,NULL,'Ba Gua','No-Beacon','Reflection','/posts/1/This is also my question extension270.txt',NULL,'2016-02-16 07:26:50','2016-02-25 20:51:04',1,NULL,NULL,NULL),(41,'my testeras32',NULL,2,4,NULL,NULL,'Atheism','US-SW-ACE','Writings','/posts/2/my testeras32.txt',NULL,'2016-02-17 05:32:25','2016-02-25 06:16:06',2,NULL,NULL,NULL),(42,'masdfasds',NULL,0,3,NULL,NULL,'Atheism','US-SW-7DA','Writings','/posts/6/masdfasds.txt',NULL,'2016-02-17 07:01:49','2016-02-17 07:10:22',6,NULL,NULL,NULL),(43,'tester323',NULL,1,2,NULL,NULL,'Adaptia','No-Beacon','Reflection','/posts/1/tester323.txt',NULL,'2016-02-19 09:30:11','2016-02-23 21:58:39',1,NULL,NULL,NULL),(44,'talents',NULL,0,0,NULL,NULL,'Adaptia','US-SW-ACE','Reflection','/posts/2/talents.txt',NULL,'2016-02-19 10:22:45','2016-02-23 06:42:19',2,1,NULL,NULL),(45,'testas',NULL,1,0,NULL,NULL,'Adaptia','No-Beacon','Writings','/posts/1/testas.txt',NULL,'2016-02-20 03:34:28','2016-02-24 03:34:12',1,NULL,NULL,NULL),(46,'My first big post yipppie!',NULL,0,1,NULL,NULL,'Adaptia','No-Beacon','Reflection','/posts/8/My first big post yipppie!.txt',NULL,'2016-02-23 06:49:58','2016-02-23 06:50:45',8,NULL,NULL,NULL),(47,'big tester',NULL,0,2,NULL,NULL,'Ba Gua','US-CS-SFR','Reflection','/posts/1/big tester.txt',NULL,'2016-02-24 06:49:26','2016-02-25 04:30:47',1,NULL,NULL,NULL),(48,'asdf2323',NULL,0,2,NULL,NULL,'Ba Gua','US-CS-SFR','Writings','/posts/8/asdf2323.txt',NULL,'2016-02-25 06:21:28','2016-04-07 20:16:29',8,1,NULL,NULL),(49,'This is my test post',NULL,4,4,NULL,NULL,'Atheism','US-SW-IHOM2','Reflection','/posts/1/This is my test post.txt',NULL,'2016-02-25 20:31:32','2016-04-29 21:32:33',1,NULL,NULL,NULL),(50,'My first post here:',NULL,1,1,NULL,NULL,'Ba Gua','No-Beacon','Writings','/posts/14/My first post here:.txt',NULL,'2016-03-21 06:41:34','2016-04-03 01:43:22',14,1,NULL,NULL),(51,'My test drip post',NULL,1,2,NULL,NULL,'Atheism','Us-FD-FW','Reflection','/posts/2/My test drip post.txt',NULL,'2016-03-23 01:47:14','2016-03-28 20:41:59',2,1,NULL,NULL),(52,'new post',NULL,0,3,NULL,NULL,'Adaptia','US-IS-022','Writings','/posts/1/new post.txt',NULL,'2016-03-23 05:28:12','2016-04-07 22:23:42',1,NULL,NULL,NULL),(53,'Thisis my tester',NULL,1,4,NULL,NULL,'Ba Gua','US-SW-IHOM2','Reflection','/posts/1/Thisis my tester.txt',NULL,'2016-03-25 05:25:30','2016-03-26 07:44:02',1,NULL,NULL,NULL),(54,'New poster',NULL,1,2,NULL,NULL,'Adaptia','US-SW-ACE','Reflection','/posts/2/New poster.txt',NULL,'2016-03-28 20:46:32','2016-04-02 23:33:13',2,1,NULL,NULL),(55,'My new draft',NULL,0,0,NULL,NULL,'Buddhism','US-SA-HASDF','Reflection','/posts/1/My new draft.txt',NULL,'2016-03-28 23:41:17','2016-04-07 07:27:01',1,1,NULL,NULL),(56,'This tester',NULL,1,2,NULL,NULL,'Adaptia','US-SW-IHOM2','Reflection','/posts/1/This tester.txt',NULL,'2016-04-01 05:28:59','2016-04-07 20:15:32',1,NULL,NULL,NULL),(57,'Hi this is my first post',NULL,0,0,NULL,NULL,'Christianity','No-Beacon','Reflection','/posts/20/Hi this is my first post.txt',NULL,'2016-04-07 01:44:23','2016-04-07 01:44:23',20,NULL,NULL,NULL),(58,'This post is enough',NULL,2,3,NULL,NULL,'Adaptia','No-Beacon','Reflection','/posts/17/This post is enough.txt',NULL,'2016-04-07 06:48:29','2016-05-02 06:01:42',20,NULL,NULL,NULL),(59,'My first post',NULL,0,0,NULL,NULL,'Adaptia','No-Beacon','Reflection','/posts/22/My first post.txt',NULL,'2016-04-07 20:13:14','2016-04-07 21:38:04',20,NULL,NULL,NULL),(60,'My new post',NULL,1,1,NULL,NULL,'Adaptia','No-Beacon','Reflection','/posts/23/My new post.txt',NULL,'2016-04-07 22:21:07','2016-04-11 00:18:06',20,NULL,NULL,NULL),(61,'My new post',NULL,0,0,NULL,NULL,'Adaptia','No-Beacon','Reflection','/posts/24/My new post.txt',NULL,'2016-04-07 22:32:22','2016-04-07 22:33:46',20,NULL,NULL,NULL),(63,'whatcha know',NULL,0,0,NULL,NULL,'Adaptia','No-Beacon','Reflection','/posts/26/whatcha know.txt',NULL,'2016-04-07 22:45:19','2016-04-07 22:45:25',20,NULL,NULL,NULL),(64,'my first posts 2',NULL,0,0,NULL,NULL,'Adaptia','No-Beacon','Reflection','/posts/27/my first posts 2.txt',NULL,'2016-04-07 22:49:37','2016-04-07 22:49:49',20,NULL,NULL,NULL),(67,'Test belief',NULL,0,0,NULL,NULL,'Atheism','No-Beacon','Reflection','/posts/8/Test belief.txt',NULL,'2016-04-09 01:51:26','2016-04-09 01:51:26',8,NULL,NULL,NULL),(68,'This is my longer posthis ',NULL,2,3,NULL,NULL,'Ba Gua','No-Beacon','Writings','/posts/20/This is my longer posthis .txt',NULL,'2016-04-11 05:48:43','2016-05-02 05:22:07',20,NULL,NULL,NULL),(69,'This is my poster23',NULL,0,1,NULL,NULL,'Zoroastrianism','US-SW-IHOM2','Writings','/posts/1/This is my poster23.txt',NULL,'2016-04-11 07:58:11','2016-04-18 05:03:42',1,NULL,NULL,NULL),(70,'My first post yupppie!',NULL,1,1,NULL,NULL,'Ba Gua','No-Beacon','Reflection','/posts/31/My first post yupppie!.txt',NULL,'2016-04-12 06:59:08','2016-04-15 04:46:02',31,NULL,NULL,NULL),(71,'test post2342',NULL,1,2,NULL,NULL,'Adaptia','US-SA-HASDF','Discussion','/posts/1/test post2342.txt',NULL,'2016-04-18 07:18:06','2016-04-18 07:30:14',1,NULL,NULL,NULL),(72,'my first post',NULL,0,0,NULL,NULL,'Adaptia','No-Beacon','Discussion','/posts/33/my first post.txt',NULL,'2016-04-18 22:16:14','2016-04-18 22:16:14',33,NULL,NULL,NULL),(74,'myseconddraft',NULL,0,0,NULL,NULL,'Adaptia','No-Beacon','Discussion','/posts/33/myseconddraft.txt',NULL,'2016-04-19 02:07:34','2016-04-19 02:07:34',33,NULL,NULL,NULL),(75,'My tester of a new post',NULL,0,2,NULL,NULL,'Adaptia','US-SA-HASDF','Discussion','/posts/1/My tester of a new post.txt',NULL,'2016-04-19 08:04:31','2016-04-21 22:08:39',1,NULL,NULL,NULL),(76,'newer tester6656asd2',NULL,0,0,NULL,NULL,'Buddhism','US-SW-23','Reflection','/posts/1/newer tester6656asd2.txt',NULL,'2016-04-21 21:59:41','2016-04-21 21:59:41',1,NULL,NULL,NULL),(77,'My love is Vivian! And God!!',NULL,0,0,NULL,NULL,'Indigenous','No-Beacon','Writings','/posts/33/My love is Vivian! And God!!.txt',NULL,'2016-04-21 22:01:55','2016-04-21 22:01:55',33,NULL,NULL,NULL),(78,'viv is amazing and I love Vivian!',NULL,0,1,NULL,NULL,'Christianity','US-SW-23','Reflection','/posts/8/viv is amazing and I love Vivian!.txt',NULL,'2016-04-21 22:02:34','2016-04-27 02:00:11',8,NULL,NULL,NULL),(79,'My first poster',NULL,0,3,NULL,NULL,'Adaptia','TK-Sesdr','Discussion','/posts/1/My first poster.txt',NULL,'2016-04-26 19:38:57','2016-04-27 01:58:19',1,NULL,43.773175,11.255949),(80,'My first',NULL,1,1,NULL,NULL,'Adaptia','US-SW-23','Discussion','/posts/29/My first.txt',NULL,'2016-04-27 01:59:18','2016-04-28 07:25:16',29,NULL,48.505077,-122.230191),(81,'this is my post title',NULL,1,2,NULL,NULL,'Druze','No-Beacon','Discussion','/posts/33/this is my post title.txt',NULL,'2016-04-27 06:29:42','2016-05-02 05:54:21',33,NULL,NULL,NULL),(82,'This is my first post',NULL,1,2,NULL,NULL,'Hinduism','US-SW-IHOM2','Discussion','/posts/1/This is my first post.txt',NULL,'2016-04-28 06:42:23','2016-04-28 07:24:10',1,NULL,NULL,NULL),(83,'My sweeet post',NULL,0,0,NULL,NULL,'Buddhism','TK-Sesdr','Discussion','/posts/33/My sweeet post.txt',NULL,'2016-04-28 07:20:21','2016-04-28 07:20:21',33,NULL,43.773175,11.255949),(84,'New poster2234',NULL,1,0,NULL,NULL,'Adaptia','IT-FLR-BOSC','Discussion','/posts/1/New poster2234.txt',NULL,'2016-04-29 19:41:23','2016-04-30 06:50:12',1,NULL,43.768541,11.261326),(85,'Newwe',NULL,1,4,NULL,NULL,'Atheism','No-Beacon','Discussion','/posts/33/Newwe.txt',NULL,'2016-04-29 20:30:39','2016-05-11 22:40:02',33,NULL,NULL,NULL),(86,'my new poster',NULL,1,2,NULL,NULL,'Adaptia','IT-FLR-Duomo','Discussion','/posts/1/my new poster.txt',NULL,'2016-04-30 02:10:40','2016-05-01 00:42:08',1,NULL,43.773175,11.255949),(87,'Tester',NULL,0,1,NULL,NULL,'Adaptia','IT-FLR-Duomo','Discussion','/posts/1/Tester.txt',NULL,'2016-05-01 01:18:58','2016-05-01 03:28:15',1,NULL,43.773175,11.255949),(88,'new may post',NULL,1,2,NULL,NULL,'Adaptia','IT-FLR-BOSC','Discussion','/posts/15/new may post.txt',NULL,'2016-05-01 03:29:07','2016-05-02 06:20:36',15,NULL,43.768576,11.262335),(89,'wooohoo ',NULL,0,0,NULL,NULL,'Adaptia','No-Beacon','Reflection','/posts/1/wooohoo .txt',NULL,'2016-05-02 06:17:10','2016-05-12 02:06:01',1,NULL,NULL,NULL),(90,'My new post',NULL,1,0,NULL,NULL,'Adaptia','IT-FLR-Duomo','Discussion','/posts/2/My new post.txt',NULL,'2016-05-03 05:51:06','2016-05-09 06:45:12',2,NULL,43.773175,11.255949),(91,'This cool',NULL,0,1,NULL,NULL,'Adaptia','No-Beacon','Discussion','/posts/1/This cool.txt',NULL,'2016-05-09 06:43:48','2016-05-12 02:10:28',1,NULL,NULL,NULL),(92,'My first post',NULL,1,4,NULL,NULL,'Buddhism','No-Beacon','Nature','/posts/1/My first post.txt',NULL,'2016-05-11 21:36:32','2016-05-12 03:11:24',1,NULL,NULL,NULL),(93,'This si my first post',NULL,0,0,NULL,NULL,'Buddhism','No-Beacon','Reflection','/posts/33/This si my first post.txt',NULL,'2016-05-11 22:21:15','2016-05-12 03:11:24',33,NULL,NULL,NULL),(94,'This is my post',NULL,0,1,NULL,NULL,'Atheism','US-SA-HASDF','Discussion','/posts/1/This is my post.txt',NULL,'2016-05-13 18:08:06','2016-05-13 18:11:28',1,NULL,NULL,NULL),(95,'Hey my first post here!',NULL,1,2,NULL,NULL,'Christianity','US-SW-Idea','Reflection','/posts/35/Hey my first post here!.txt',NULL,'2016-05-13 18:38:28','2016-05-15 21:48:02',35,NULL,48.507481,-122.249503),(96,'my first post',NULL,0,0,NULL,NULL,'Adaptia','No-Beacon','Discussion','/posts/36/my first post.txt',NULL,'2016-05-19 03:17:19','2016-05-19 03:17:19',36,NULL,NULL,NULL);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `elevation` int(10) unsigned NOT NULL,
  `extension` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `questions_question_unique` (`question`),
  KEY `questions_user_id_foreign` (`user_id`),
  CONSTRAINT `questions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (5,'This is my first questions?',5,16,'2016-01-21 05:16:40','2016-02-17 01:03:54',1),(6,'Second Question of the week that is long?',4,7,'2016-01-31 17:47:18','2016-02-14 07:21:09',2),(9,'test of poster2s',2,9,'2016-02-07 04:13:55','2016-02-24 03:35:16',1),(24,'Where does influence come from??',2,7,'2016-02-28 04:50:49','2016-03-25 06:17:46',8),(25,'How do we become perfect lovers?',5,4,'2016-04-07 07:01:00','2016-04-18 07:30:48',20),(26,'This is my new question whatacha think?',0,1,'2016-04-27 06:40:08','2016-05-01 01:05:24',2),(30,'Can we lo2ve someone of a different belief?',1,2,'2016-05-16 07:45:29','2016-05-16 08:29:05',1);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `songs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `song_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `elevation` int(10) unsigned NOT NULL,
  `extension` int(10) unsigned NOT NULL,
  `lyrics_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `artist_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `songs_artist_id_foreign` (`artist_id`),
  CONSTRAINT `songs_artist_id_foreign` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `songs` WRITE;
/*!40000 ALTER TABLE `songs` DISABLE KEYS */;
/*!40000 ALTER TABLE `songs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sponsor_promo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sponsor_promo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tier1` int(11) NOT NULL,
  `tier2` int(11) NOT NULL,
  `tier3` int(11) NOT NULL,
  `promo1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `promo2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `promo3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sponsor_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sponsor_promo_sponsor_id_foreign` (`sponsor_id`),
  CONSTRAINT `sponsor_promo_sponsor_id_foreign` FOREIGN KEY (`sponsor_id`) REFERENCES `sponsors` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sponsor_promo` WRITE;
/*!40000 ALTER TABLE `sponsor_promo` DISABLE KEYS */;
/*!40000 ALTER TABLE `sponsor_promo` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sponsor_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sponsor_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adult` tinyint(1) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `admin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zip` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sponsor_requests` WRITE;
/*!40000 ALTER TABLE `sponsor_requests` DISABLE KEYS */;
INSERT INTO `sponsor_requests` VALUES (1,'This asf a ','234 ASdf ','asdfj','asdf','234-2342-234','http://gonzaga.edu',1,1,'2016-03-31 17:10:51','2016-04-18 06:16:08','','','this@g.com',NULL),(2,'My new sponsor pleace','2323 SASdf','US','SW','2323234232','asdfasdfasdfasdf',1,20,'2016-04-07 06:54:02','2016-04-07 07:37:01','Tre-Uniti','Requested','asdfasdf@c.com',NULL),(3,'this tester','tasdfasdf','US','SW','324-2342-2342','http://gonzaga.edu',1,20,'2016-04-07 20:14:38','2016-04-07 21:38:04','Tre-Uniti','Requested','asdfasdf@c.com2',NULL),(4,'This is myasdf','23423 Burrows Lane','asdfasdfasdf','asdfasdfasdf','234234234asdf','asdfasdfasdf',0,33,'2016-04-19 06:03:24','2016-04-19 06:11:05','Tre-Uniti','Requested','asasd@c.om',NULL),(5,'new tester','a2342 cas','US','Sedro-Woolley','3603338783','234234asdfasdf',0,1,'2016-04-26 06:01:55','2016-04-26 06:01:55','Tre-Uniti','Requested','brendan.mcgoffin@tre-uniti.org23',NULL);
/*!40000 ALTER TABLE `sponsor_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sponsors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sponsors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `view_budget` int(10) unsigned NOT NULL,
  `views` int(10) unsigned NOT NULL,
  `adult` tinyint(1) NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `missed` int(10) unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `clicks` int(10) unsigned NOT NULL,
  `click_budget` int(10) unsigned NOT NULL,
  `lat` double(10,6) DEFAULT NULL,
  `long` double(10,6) DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sponsors` WRITE;
/*!40000 ALTER TABLE `sponsors` DISABLE KEYS */;
INSERT INTO `sponsors` VALUES (1,'Tre-Uniti','https://tre-uniti.org','360-333-8783','/sponsor_photos/1/Tre-Uniti.png','Live',3000,603,0,'US','Sedro-Woolley-SW','2016-01-11 05:44:07','2016-05-19 00:29:13',0,'brendan.mcgoffin@tre-uniti.org','cus_8Ngea6hXF7iUnX',2,'234 Asd ',0,1000,48.511376,-122.247649,NULL),(2,'tester2','http://gmail.com','32434234234234','/sponsor_photos/2/tester2-Apr-26-2016.jpg','Active',32000,224,0,'US','SE','2016-01-14 02:05:21','2016-05-19 03:56:03',0,'bmsdf@g.com',NULL,0,'',1,10000,NULL,NULL,NULL),(3,'Woolley Market','http://woolleymarket.com/','360-982-2649','/sponsor_photos/3/Woolley_Market.png','Live',3232200,321,0,'US','SW','2016-01-14 02:50:36','2016-05-16 20:09:38',0,'brendan.mcgoffin@tre-uniti.org2','cus_7ytq1DmC4slIxs',1,'234 Burws',1,10000,0.000000,0.000000,'98284'),(5,'New Mes','https://google.com','342-234-2342','/sponsor_photos/5/New_Mes.jpg','active',1000,5,1,'US','SW2','2016-03-23 20:05:07','2016-04-18 06:42:16',0,'bm234@c.com',NULL,0,'234 Burs',0,1000,NULL,NULL,NULL),(6,'DigitalOcean','http://msn.com','234-234-2342','/sponsor_photos/6/DigitalOcean-Apr-11-2016.jpg','Live',1510,23,1,'US','IS','2016-03-23 22:04:52','2016-05-15 22:36:29',0,'bmcgoffin14@gmail.com','cus_8952catHZxlwK0',1,'2342 Burows Lane',31,1000,0.000000,0.000000,'98284'),(7,'My brand new sponsor','http://hsddf2sth.com','234-2342-234','/sponsor_photos/7/My_brand_new_sponsor.jpg','Live',10000,24,1,'US','Nse','2016-03-25 04:58:39','2016-05-10 18:40:54',0,'asdf@ca.com','cus_8GoiwYeJH7CxrW',20,'2342 Burows Lane',0,2000,48.502801,-122.236921,'98284');
/*!40000 ALTER TABLE `sponsors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sponsorships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sponsorships` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sponsor_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sponsorships_sponsor_id_foreign` (`sponsor_id`),
  KEY `sponsorships_user_id_foreign` (`user_id`),
  CONSTRAINT `sponsorships_sponsor_id_foreign` FOREIGN KEY (`sponsor_id`) REFERENCES `sponsors` (`id`),
  CONSTRAINT `sponsorships_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sponsorships` WRITE;
/*!40000 ALTER TABLE `sponsorships` DISABLE KEYS */;
INSERT INTO `sponsorships` VALUES (13,2,'2016-01-15 07:54:50','2016-01-15 07:54:50',2),(14,1,'2016-01-15 08:17:10','2016-01-15 08:17:10',5),(18,7,'2016-03-25 06:48:25','2016-03-25 06:48:25',13),(22,1,'2016-04-11 06:37:19','2016-04-11 06:37:19',20),(25,1,'2016-04-15 04:53:08','2016-04-15 04:53:08',1),(26,3,'2016-04-28 07:19:53','2016-04-28 07:19:53',33);
/*!40000 ALTER TABLE `sponsorships` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `request` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(10) unsigned NOT NULL,
  `zendesk_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `supports_user_id_foreign` (`user_id`),
  CONSTRAINT `supports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `supports` WRITE;
/*!40000 ALTER TABLE `supports` DISABLE KEYS */;
INSERT INTO `supports` VALUES (42,'This is my new support request with ZenDesk','User','Open','2016-05-11 03:09:47','2016-05-11 03:09:48',1,'',''),(43,'whatcha know?','Beacon','open','2016-05-11 03:17:24','2016-05-11 03:46:52',1,'',''),(45,'What do you think of the following data dump? beacon9','vulnerability','solved','2016-05-11 04:23:14','2016-05-11 06:46:45',1,'32','this is big! and9'),(46,'This is what I think what about you? My new','intolerance','solved','2016-05-11 04:50:51','2016-05-11 06:46:37',1,'33','This is my new test'),(47,'This test','vulnerability','open','2016-05-19 06:00:34','2016-05-19 06:00:34',36,'','my support'),(48,'This test','vulnerability','open','2016-05-19 06:04:42','2016-05-19 06:04:42',36,'','my support'),(49,'This test','vulnerability','open','2016-05-19 06:06:18','2016-05-19 06:06:19',36,'44','my support');
/*!40000 ALTER TABLE `supports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `nymi_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo_path_temp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `elevation` int(10) unsigned NOT NULL,
  `extension` int(10) unsigned NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `emailToken` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `frequency` int(10) unsigned NOT NULL,
  `location` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_handle_unique` (`handle`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Tre-Uniti','brendan.mcgoffin@tre-uniti.org','$2y$10$E.oeTFvCVqRsMILzn2oqieNOQ8/YvsFYLnMkn5pqr9zJc9r3etruO',NULL,'/user_photos/1/Tre-Uniti-May-03-2016.jpg','',39,85,2,1,'','Z37J3MwxqVEVngZZPpb3v0fTqrDuXwxzrOTW94Ps1U90JiBeReFWXOwpJZLe','2015-12-20 08:05:53','2016-05-19 02:50:51',3,2),(2,'Amaricus','br@belle-idee.org','$2y$10$.OsASDTCohmZ.WHAnLUDaedS22vR699iwP1OTPgwnBu79BZHyKPYy',NULL,'/user_photos/2/Amaricus.jpg','',26,27,2,1,'','902VR9Jrq8Wo5uy5Z2OVGQFCna8Z2EeNFMSXczZMStJRMkMbATPIDVWHbQsl','2015-12-20 08:14:19','2016-05-12 02:02:03',1,2),(5,'zagmail','bmcgoffin@zagmail.gonzaga.edu','$2y$10$SFSVsG7j6zi9.QYo/QmffO3utIuiP1QHpaTmNGtn78vaxSK5/gqVi',NULL,'','',3,6,0,1,'','MXB21zvohhIlMBKURfM626k1MOcoK3j1mICTYK2oQJOG2GPXMMO89cGVqIdy','2015-12-28 17:15:45','2016-02-19 10:25:06',0,NULL),(6,'BigBoyz','bmcgoffin12@gmail.com','$2y$10$MnLSfar/YATf2prrDpZgDehktM7Z2RAq7VtJJni0g/zmY9QMdjdz6',NULL,'/user_photos/6/BigBoyz.PNG','',4,26,1,1,'','79piVtevs1XOE24DhpoeoQZWUC8o7epnoviGYQASLSrrAccFNbWsz7uc3qlF','2016-01-20 06:38:03','2016-02-23 06:40:43',0,NULL),(7,'tester','bmcgoffin15@gmail.com','$2y$10$S3CStC3tIQBlFYnScm1t/.eS8ckXwQQzV5iC0gs6kkKQ7zzhuzRae',NULL,'','',0,0,0,0,'lcYk5s7JuMXS58ZBmo0kJnfedajdBe',NULL,'2016-02-16 03:38:33','2016-02-16 03:38:33',0,NULL),(8,'Viv','bm@g.com','$2y$10$m4GkV9ZUVPPrrd/rY6w7G.1p5/FErRoL686v1VaKPgdyv8qkP7tvi',NULL,'/user_photos/8/Viv-Apr-11-2016.png','',9,12,0,1,'','UG20rD77NarBH7I32NaNXSjkcDjQVdtKX2qnm7FNzbmIZl4a6NDCgSQlfNvX','2016-02-23 05:27:04','2016-04-27 02:00:11',0,NULL),(9,'noBeta','bm3@g.com','$2y$10$.2POeDkNAHmEbsYKlCeuhODoXSafy965Xyw1Yi5lusCs217PQzuoS',NULL,'','',0,0,0,1,'','QuKoKSjeHurG8S8jrJaH0ETQKTjB7xodDKtVC1obyxT5oaVhDbpZBB4w1K3d','2016-03-21 04:48:06','2016-04-27 01:58:38',0,NULL),(13,'thisiscool','bm5@g.com','$2y$10$NndfkiFF4DUAAmyxUNGK6uNWak7W6frUaBZJc5mpfJcrlnTs62tDG',NULL,'','',0,0,0,1,'','innOFymm7IB7Bwwe3h5ZoPYukE5zfbxjQrltutfyyLne9abp7PWI2YTeqaG6','2016-03-21 06:09:17','2016-03-21 06:19:41',0,NULL),(14,'mynewaccount','b2@gm.com','$2y$10$.ngmVQxTy3vHdLEM9fmYsOU8G9mNm8wsHLAdbXOD5RLf1wCYjvkyS',NULL,'','',1,2,0,1,'','PjoAt963kM3Przp4RemHJkMONVGOiREkLkBuEHrK3onIauBs9EldFGabbL29','2016-03-21 06:20:28','2016-03-30 09:34:27',0,NULL),(15,'news1','bm7@g.com','$2y$10$.Jt6KOBGN10L/dTQRi4azeyRZIbWNF4UY0q73/Q5OnqJj1Sre7l0i',NULL,'','',1,2,2,1,'','GkR7c4XIsXJkpzSTlzG18nyJ6Khj9TZr0sX0OhLXRbyUtqbSfB435CveE4Jq','2016-03-21 07:10:27','2016-05-02 06:37:48',0,2),(16,'NewDay','bm8@g.com','$2y$10$C11Un1ws1BWS8MeZGVwDGO4taY6AqO9shX1MAyTBUazT9OS0z6uWi',NULL,'','',0,0,0,1,'','FNOMH9QFXIguBERtB2NBp8QKXBmjWGq95wR7afZvxvdlxxrP33DY4pmbr5Uc','2016-03-29 16:59:19','2016-05-02 07:47:20',0,1),(19,'tester2','b3@g.com','$2y$10$0lwiXXQ4b0.c35PA36bNlei2lPWB.hcj8DyRE62ypv8cRDrjIZuJy',NULL,'','',0,0,0,1,'',NULL,'2016-04-06 18:57:31','2016-04-06 19:48:49',0,NULL),(20,'Transferred','b@m.com','$2y$10$ihjVHT.8BewmZZphdkfrMOarxfC2chl3qZH0fSPUVarinWez2HbjG',NULL,'/user_photos/20/Transferred-Apr-12-2016.PNG','',14,9,0,1,'','vFNsXRCZybH1ZWx2m3z8jNtATrri7YPbYQPQSWQvpZv0GeaXJvGd9xUJSdIe','2016-04-07 01:39:08','2016-05-02 06:20:06',0,NULL),(29,'anothertest','bm4@g.com','$2y$10$3WzYa6NI5rpJEkZO2wffRu6EYEGAgy3RTdFsDouood9gEue2wi89W',NULL,'','',1,1,0,1,'','zZ1IreycyBzZ3ncaaeijIQ6EJ6UINSj9nLkacgvjtbabDHHTjODxXo5witHC','2016-04-09 02:07:27','2016-04-28 07:25:16',0,NULL),(30,'Mcgof','bm6@g.com','$2y$10$7carqpa2FuQIJOwKtN5d7Od63qqCmYhcTtGyo1lZzkbNDckg8kRem',NULL,'','',0,0,0,1,'','wG6QKHtzirlbgnu4pBq7vU2gn5s1RoJZ8UZurGB9e7P7IMw17c1PA2wGQq7m','2016-04-12 06:51:00','2016-04-12 06:56:34',0,NULL),(31,'Mcgof2','bm9@g.com','$2y$10$o33xRWAl96x64Da1vzsIfuw3Ykb3TWEwI/.DiKKA6cACNOJ0Y6cTK',NULL,'','',1,1,0,1,'','7SRH74Ahyhe588ejFk4xMB1FWbpXs8qxGXvyXeQldy5M5kN9N80XF1tnKg2C','2016-04-12 06:56:56','2016-04-15 04:46:02',0,NULL),(32,'tester234','bm10@g.com','$2y$10$D8aF8fdj6fN05IXU8HFycOcevbGIZGYUFUwinhcrSe2UkfcqiWSXe',NULL,'','',0,0,0,1,'',NULL,'2016-04-12 17:41:37','2016-04-12 17:42:15',0,NULL),(33,'MyohMy','bm0@g.com','$2y$10$KKGN34EhF/InYpoEaJyDquwn3ZoMlKIX4zgIZM4fJvglZ5Mwn/wY.',NULL,'/user_photos/33/MyohMy-Apr-18-2016.png','',4,6,0,1,'','0n8s84tPRjHtRUYBk0gzba7hBKfam60F2C1WYFVzpqvSasRQaZn1IxdW4Ako','2016-04-13 07:36:42','2016-05-12 02:36:30',3,2),(34,'asdfasdf','asdfasdfasdfasddf@belle-idee.org','$2y$10$tBXQjVc4/X5ZLw4pj.bF0Or58Xb5JXw08JdKFXcIh6EFcBozk9PVS',NULL,'','',0,0,0,0,'4LSv6l0gu0NCqQhc7sq2pz6RCP35J5',NULL,'2016-05-10 06:35:53','2016-05-10 06:35:53',0,NULL),(35,'Laravel 5.2','bm23@gmail.com','$2y$10$Ao7ybjv8wpGd.Nsrb6zia.GS4l9ewGfy..x.F0WnFOP0bLIxdThje',NULL,'','',1,2,0,1,'',NULL,'2016-05-13 18:30:13','2016-05-15 21:48:02',3,1),(36,'test3423','bmcgoffin14@gmail.com','$2y$10$L5y540eVatz2x5g9Z69FUevljzgB2qKI8hOLg7O.v9VTEzDCh5GmK',NULL,'','',0,0,0,1,'',NULL,'2016-05-19 02:57:50','2016-05-19 03:17:03',3,2);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `versions_post_id_foreign` (`post_id`),
  CONSTRAINT `versions_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

